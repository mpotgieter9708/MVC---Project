1. How to install system on machine
a)Copy the script file "Assessment4.1" to xampp under htdocs folder.
b)Restore the database in sqlyog.
c)Stop the IIS server and start the apache server.
d)You will now be able to go to a browser and type the following: "localhost/Assessment4.1/Default.php";

2. Username and passwords
a) Role = Client: 
	Username: JacobT1
	Password: JacobT1
b)Role = Employee:
	Username: Hannes
	Password: Hannes
c)Role = Manager:
	Username: Valencia
	Password: Valencia