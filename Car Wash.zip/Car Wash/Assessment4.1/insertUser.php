<?php

include 'Connect.php';
include 'registerClient.php';

$sql = "INSERT INTO user(user_password,user_name) 
    VALUES 
    ('$_GET[userpassword]','$_GET[username]')";
$sql1 = "INSERT INTO userrole(role_id,user_name) 
        VALUES (1,'$_GET[username]')";

if(!mysql_query($sql,$con))
{
    die("Error". mysql_error());
}
if(!mysql_query($sql1,$con))
{
    die("Error". mysql_error());
}   
mysql_close($con);
?>
