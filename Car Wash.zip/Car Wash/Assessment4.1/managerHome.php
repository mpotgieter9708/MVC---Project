<?php
include 'views/menuManager.php';

?>
<html>
<div class="row">
        <div class="col-md-10 col-md-offset-1">
            
            <div class="panel panel-default panel-background">
                
                <h1>Manager's Menu</h1>
                <hr />
                <div class="panel-body">
                    <center><p><strong>** What can we do for you today**</strong></p></center>
                    <h2>Things you can do :</h2>
                    <ul>
                        <li>Add Employees</li>
                        <li>Update Services</li>
                        <li>Add Services</li>
                        <li>Assign Jobs to Employees</li>
                        <li>View Bookings Summary Report </li>
                        <li>View Invoice Report </li>
                        <li>View Weekly Bookings Report </li>
                        <li>View Customer Comments Report </li>
                        <li>View Customer Promotion Report </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</html>


