<html>
    <title>Register</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     
    <body>
        <div class="navbar">
            <a href="Default.php"><i class="fa fa-home"></i>Home</a>
            <div class="navbar-right">
                <a href="index.php">Log in<i class="fa fa-sign-in"></i></a>
            </div>
  </div>
        <br>
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
               
               
                <div class="panel-body">
                    <h4>Register </h4>
                    <form action="insertUser.php" method="GET" >
                        User name:<input type="text" name="username" value="" class="form-control"/><br>
                        Password:<input type="password" name="userpassword" value="" class="form-control"/> <br>
                        <input type="submit" value="Register" class="btn-default"/>
                    </form>

