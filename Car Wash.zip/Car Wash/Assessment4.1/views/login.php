<DOCTYPE html>
<html>
    <TITLE>Log in</TITLE>
 <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
a.one:link {color:#ff0000;}
a.one:visited {color:cyan;}
a.one:hover {color:hotpink;}
</style>
        <script>
        function checkForm(form)
        {
            if(form.username.value == "") {
            alert("Error: Username cannot be blank!");
            form.username.focus();
            return false;
         }
            re = /^\w+$/;
            if(!re.test(form.username.value)) {
            alert("Error: Username must contain only letters, numbers and underscores!");
            form.username.focus();
            return false;
            }
            
            if(form.password.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        form.password.focus();
        return false;
      }
      
    }
</script>
     </head>
     
  <body>
      <div class="navbar">
            <a href="Default.php"><i class="fa fa-home"></i>Home</a>
            <div class="navbar-right">
            <a href="index.php">Log in<i class="fa fa-sign-in"></i></a>
            
            </div>
  </div>
      <BR>
       <div class="row">
        <div class="col-md-5 col-md-offset-4">

            
            <div class="panel panel-primary panel-background">
                <div class="panel-body">
                    
                    <h4>Please Provide Log in Details</h4>
    <form action='' method=POST onsubmit="return checkForm(this);">
        User name<input type=text name=username class="form-control"><br>
	Password<input type=password name=password class="form-control"><br>
	<input type=hidden name=controller value=login><input type=hidden name=action value=login>
        <input type=submit value="Log in" class="btn-default">
        <br><BR>Don't have a local account yet ? <a class="one" href="?controller=register&action=registerClient">Register<i class="fa fa-user-plus"></i></a>
    </form>

    <?php 
require_once('routes.php'); 
	?>

                </DIV>
            </DIV>
        </DIV>
       </DIV>
  </body>
</html>
