<html>
    <title>All Comments</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>My Comments <i class="fa fa-comments-o"></i></h1>
                <hr />
                <div class="panel-body"> 

<?php
/************************************************************************
* This page is used to display a list of subjects for a lecturer
************************************************************************/

// start with the dropdown that is populated with subject code and name

//echo "<h1>My Vehicles<h1>";
echo "<form method = GET><table border=1><tr>
<th>Description</th><th>Customer Surname</th><th>Customer Initials</th><th>Registration No</th>
</tr>";
foreach ($allComments as $comment)
{
echo "<tr>
    
<td>$comment->description</td>
<td>$comment->surname </td>
    <td>$comment->initials</td>
        <td>$comment->regno</td>
            
</tr>";
    
}
?>
</table></form>

<?php
echo "<input type=hidden name=controller value = employee>";
echo "<input type=hidden name=action value = showAllComments>";

?>
                </div>
            </div>
        </div>
     </div>
                    
</html>






