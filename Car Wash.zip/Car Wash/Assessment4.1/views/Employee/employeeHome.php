
<html>
    <title>Home Page</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <body>  
<div class="row">
        <div class="col-md-5 col-md-offset-3">
           
            <div class="panel panel-default panel-background">
                <h1>Employees's Menu</h1>
                <hr />
                <div class="panel-body">
                    <center><p><strong>** What can we do for you today**</strong></p></center>
                    <h2>Things you can do :</h2>
                    <ul>
                        <li>Check a Vehicle for Damages</li>
                        <li>Check Available Jobs</li>
                        <li>Create Invoices</li>
                        <li>View All Comments</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
