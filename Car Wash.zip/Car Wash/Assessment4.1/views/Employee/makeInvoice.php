<?php?>

<html>
    <title>Make Invoices</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <script>
         function validateForm() {
            var x = document.forms["myForm"]["idate"].value;
            var d = new Date();
            var year = d.getFullYear();
            var month = '' + (d.getMonth() + 1);
            var day = '' + d.getDate();
            
            if (month.length < 2) month = "0" + month;
            if (day.length < 2) day = "0" + day;
            var date = year + "-" + month + "-" + day;
            if (x < date) {
                alert("Error: Please select a valid invoice date!");
                return false;
            }
             else {
                if (x >= date)
                {
                    return true;
                }
            }
       }
       </script>
     </head>
     
    
   <div class="row">
        <div class="col-md-10 col-md-offset-1">
            
            <div class="panel panel-default panel-background">
                <h1>Make Invoices</h1>
                <hr />
                <div class="panel-body"> 
        <form action='' name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='employee'>
	<input type=hidden name=action value='addInvoice'>
        <div class="col-md-6">
            <h3>All Job Cards with No Invoices</h3>            
        <table>
            <tr> <th>Job Card No</th><th>Date</th><th>Time</th><th>Registration No</th><th>Service Type</th><th>Service Price</th></tr>
            <?php foreach ($allBookings as $booking) {
echo "<tr>
<td>$booking->jobcardno</td>
<td>$booking->date</td>
    <td>$booking->regno</td>
    <td>$booking->time</td>
        <td>$booking->sdesc</td>
            <td>$booking->sprice</td>
        
            
</tr>";
}?>
        </table>
        </div>
          <h3>Make Invoices</h3>  
        Job Card No: <select name="jobcardno" class="form-control"><?php
            foreach($allBookings as $booking){
	echo "<option value='".$booking->jobcardno."'>".$booking->jobcardno."</option>";
        }?></select><br>
        Date: <input type="date" name="idate" value="<?php echo $idate; ?>" class="form-control"/><br>
        
        <input type="submit" value="Create Invoice" class="btn-default"/>
        <center><p>**Note The Invoice Amount Is Automatically Captured When The Invoice Is Created.**</p></center>
        </form>

                </div>
            </div>
        </div>
   </div>
</html>

