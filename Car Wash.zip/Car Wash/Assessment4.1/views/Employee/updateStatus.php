<?php?>

<html>
    <title>Available Jobs</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     
    
   <div class="row">
        <div class="col-md-6 col-md-offset-3">
            
            <div class="panel panel-default panel-background">
                <h1>Available Jobs</h1>
                <hr />
                <div class="panel-body"> 
        <form action='' method=GET><input type=hidden name=controller value='employee'>
	<input type=hidden name=action value='updateStatus'>
        
                        
        <table>
            <tr> <th>Job Card No</th><th>Date</th><th>Time</th><th>Registration No</th><th>Service Type</th><th>Status</th></tr>
            <?php foreach ($allBookings as $booking) {
echo "<tr>
<td><input type='text' name='jobcardno' value='".$booking->jobcardno."' class='form-control'/></td>
<td>$booking->date</td>
    <td>$booking->time</td>
    <td>$booking->regno</td>
        <td>$booking->sdesc</td>
            <td><select name='washed' class='form-control'>
<option value=0>$booking->washed</option>
<option value=1>Washed</option>
</select></td>
<td><input type='submit' value='Update' class='btn-default'/></td>
        
            
</tr>";
}?>
        </table>
        
              </form>

                </div>
            </div>
        </div>
   </div>
</html>

