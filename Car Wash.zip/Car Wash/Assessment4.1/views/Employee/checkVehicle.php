<?php?>

<html>
    <title>Check Vehicle</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     
    
   <div class="row">
        <div class="col-md-6 col-md-offset-3">
            
            <div class="panel panel-default panel-background">
                <h1>Vehicle Checkpoint</h1>
                <hr />
                <div class="panel-body"> 
        <form action='' method=GET><input type=hidden name=controller value='employee'>
	<input type=hidden name=action value='checkVehicle'>
        
        Job Card No: <select name="jobcardno" class="form-control"><?php
            foreach($allBookings as $book){
	echo "<option value='".$book->jobcardno."'>".$book->jobcardno."</option>";
        }?></select><br>
        
        Damaged:<br>
        <input type="checkbox" name="damage" value="1" /> Yes<br>
        <input type="checkbox" name="damage" value="0" /> No<br>
        
        <br>Damage Type:<select name="damagetype" class="form-control">
            <option>--Please Select Damage Type--</option>
            <option>Windscreen Crack</option>
            <option>Vehicle Dent</option>
            <option>Paint Scratch</option>
            <option>Other</option>
        </select>
        <br><input type="submit" value="Save" class="btn-default"/>
              </form>

                </div>
            </div>
        </div>
   </div>
</html>

