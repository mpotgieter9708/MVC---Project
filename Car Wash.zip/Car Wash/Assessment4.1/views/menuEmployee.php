<DOCTYPE html>
<html>
    
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
  
  <body>
    <header>
        
       <div class="navbar">
            <a href="?controller=employee&action=home"><i class="fa fa-home"></i>Home</a>
             <a href="?controller=employee&action=showAllComments">All Comments<i class="fa fa-comments-o"></i></a>
             <a href="?controller=employee&action=addInvoice">Make Invoice<i class="fa fa-pencil"></i></a>
             <a href="?controller=employee&action=checkVehicle">Check Vehicle<i class="fa fa-pencil"></i></a>
             <a href="?controller=employee&action=updateStatus">Available Jobs<i class="fa fa-eye"></i></a>
             
             <div class="navbar-right">
             <a href="index.php">Log off<i class="fa fa-power-off "></i></a>
             <a > Hello <?php echo $surname . ', ' . $initials; ?>! <i class="fa fa-smile-o"></i> </a>
             </div>
        </div>
   <!--<div class="topnav">
  <a class="active" href="employeeHome.php">Home</a>
 <a href="?controller=employee&action=showAllComments"><i class="fa fa-eye"></i>All Comments</a>
   <div class="topnav-right">
   <a href="index.php">Log off</a>
    <a> Hello <?php //echo $initials . ', ' . $surname; ?>!</a>
  </div>
</div>-->
    </header>
      <br>

    <?php 
?>

    <footer>
    
    </footer>
  </body>
</html>





