<p>Hello there <?php echo $initials . ' ' . $surname; ?>!<p>

<p>You successfully landed on the home page. Congrats!</p>
