<html>
    <title>View Vehicle</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>My Vehicles</h1>
                <hr />
                <div class="panel-body"> 

<?php
/************************************************************************
* This page is used to display a list of subjects for a lecturer
************************************************************************/

// start with the dropdown that is populated with subject code and name

//echo "<h1>My Vehicles<h1>";
echo "<form method = GET><table border=1><tr>
<th>Registration No</th><th>Make</th><th>Model</th><th>Colour</th><th>Year</th>
</tr>";
foreach ($vehicle as $veh)
//foreach ($vehicle as $veh) 
    {
    
       
    
echo "<tr>
    
<td>$veh->regno</td>
<td>$veh->make</td>
    <td>$veh->model</td>
        <td>$veh->colour</td>
            <td> $veh->year</td>
</tr>";
    
}
?>
</table></form>

<?php
//echo "<input type=hidden name=controller value = client>";
//echo "<input type=hidden name=action value = showAllVehicles>";

?>
                </div>
            </div>
        </div>
     </div>
                    
</html>


