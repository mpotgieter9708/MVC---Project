<html>
    <title>View Bookings</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>My Bookings</h1>
                <hr />
                <div class="panel-body"> 

<?php
/************************************************************************
* This page is used to display a list of subjects for a lecturer
************************************************************************/

// start with the dropdown that is populated with subject code and name

//echo "<h1>My Vehicles<h1>";
echo "<form method = GET><table border=1><tr>
<th>Booking No</th><th>Date</th><th>Time</th><th>Registration No</th><th>Service Type</th><th>Service Price</th>
</tr>";
foreach ($booking as $book) {
echo "<tr>
<td>$book->jobcardno</td>
<td>$book->date</td>
    <td>$book->regno</td>
    <td>$book->time</td>
        <td>$book->sdesc</td>
            <td>$book->sprice</td>
        
            
</tr>";
}
?>
</table></form>

<?php
//echo "<input type=hidden name=controller value = client>";
//echo "<input type=hidden name=action value = showAllBookings>";

?>
                </div>
            </div>
        </div>
     </div>
                    
</html>


