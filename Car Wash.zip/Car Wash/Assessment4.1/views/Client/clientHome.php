
<html>
    <title>Home Page</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <body>
 
   

      <div class="row">
        <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default panel-background">
                <h1>Welcome to Ladies Car Wash </h1>
                <hr />
                <div class="panel-body">
                    <center><h2><strong>** Available service **</strong></h2></center>
                    <center><p><strong>** Prices may vary at different franchises **</strong></p></center>
                    <h3>Executive Wash R85.00</h3>
                    <p>Hand wash, Dry, Vac, Interior clean, Window clean, Dash/Trim/Typre Shine, Air freshener</p>
                    <h3>Full Wash R80.00</h3>
                    <p>Hand wash, Dry, Vac, Interior clean, Window clean</p>
                    <h3>Wash 'n Dry R50.00</h3>
                    <p>Hand wash, Full Exterior & Type/Mag Dry</p>
                    <h3>Wash 'n Go R45.00</h3>
                    <p>Hand wash, Window squeegee</p>
                    <h3>General:</h3>
                    <ul>
                        <li>Bookings essential</li>
                        <li>Drop off at 08h00. Collection from 17h00</li>
                        <li>Surcharge for S.U.V's, D/Cabs & Mini Busses</li>
                    </ul>
                     
                    
                
                </div>
            </div>
        </div>
    </div>
     </body>
</html>






