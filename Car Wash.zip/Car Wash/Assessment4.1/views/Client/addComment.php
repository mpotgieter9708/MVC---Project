<?php?>

<html>
    <title>Comment</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
        function validateForm() {
            var x = document.forms["myForm"]["description"].value;
            if (x =='') {
                alert("Error: Comment cannot be blank!");
                return false;
            }
       }
</script>
     </head>
     
    
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>Tell Us What You Think<i class="fa fa-commenting-o"></i></h1>
                <hr />
                <div class="panel-body"> 
        <form action='' name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='client'>
	<input type=hidden name=action value='addComment'>
        
        <center><p>Most of our work is obtained by recommendations from people that demand and deserve the absolute best in car care.</p></center> 
        <center><p>Tell us what you think about your experience, we'll be glad to prove our dedication and make the improvements.</p></center> 
        <br>Comment: <input type="text" name="description" value="" class="form-control"/><br>
        
            <input type="submit" value="OK" class="btn-default"/>
        </form>
                </div>
            </div>
        </div>
   </div>
</html>

