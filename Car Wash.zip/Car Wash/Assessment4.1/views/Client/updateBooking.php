<?php?>

<html>
    <title>Update Booking</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
         function validateForm() {
            var x = document.forms["myForm"]["date"].value;
            var d = new Date();
            var year = d.getFullYear();
            var month = '' + (d.getMonth() + 1);
            var day = '' + d.getDate();
            
            if (month.length < 2) month = "0" + month;
            if (day.length < 2) day = "0" + day;
            var date = year + "-" + month + "-" + day;
            
            if (x < date) {
                alert("Error: Please select a valid booking date!");
                return false;
            }
             else {
                if (x >= date)
                {
                    return true;
                }
            }
            
       }
       </script>
     </head>
     
    
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>Update Booking</h1>
                <hr />
                <div class="panel-body"> 
        <form action=''  name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='client'>
	<input type=hidden name=action value='updateBooking'>
        
        Booking No: <select name="jobcardno" class="form-control"><?php
            foreach($booking as $book){
	echo "<option value='".$book->jobcardno."'>".$book->jobcardno."</option>";
        }?></select><br>
        Date: <input type="date" name="date" value="<?php echo $bkDate; ?>" class="form-control"  pattern="(19|20)[1-9]{2}-[0-9]{2}-[0-9]{2}" title='Valid date example: 2018-01-01'/><br>
        
        Service Type: <select name="scode" class="form-control"><?php
            foreach($service as $serv){
	echo "<option value='".$serv->scode."'>".$serv->sdesc."</option>";
        }?></select><br>
            Time:<select name="time" class="form-control">
                <option>08:00</option>
                <option>09:00</option>
                <option>10:00</option>
                <option>11:00</option>
                <option>12:00</option>
                <option>13:00</option>
                <option>14:00</option>
                <option>15:00</option>
                <option>16:00</option>
            </select><br>
            <input type="submit" value="Update Booking" name="btnUpdate" class="btn-default"/>
            
        </form>
                </div>
            </div>
        </div>
   </div>
</html>

