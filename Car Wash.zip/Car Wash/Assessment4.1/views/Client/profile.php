<html>
    <title>Profile</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
        function validateForm() {
            var x = document.forms["myForm"]["surname"].value;
            if(x=='') {
                alert("Error: Surname cannot be blank!");
                return false;
            }
            else{
                if (x.length > 50)
                    {
                alert("Error: Please enter a valid surname!");
                return false;
                }
            }
            
            var y = document.forms["myForm"]["initials"].value;
            if(y == '') {
                alert("Error: Initials cannot be blank!");
                return false;
            }
            else{
                if (y.length > 5)
                    {
                alert("Error: Please enter valid initials!");
                return false;
                }
            }
            
            var a = document.forms["myForm"]["idno"].value;
            if(a == '') {
                alert("Error: ID Number cannot be blank!");
                return false;
            }
            else{
                if (a.length > 13 || a.length < 13)
                    {
                alert("Error: Please enter a valid ID number!");
                return false;
                }
            }
            
            var b = document.forms["myForm"]["contactno"].value;
            if(b == '') {
                alert("Error: Contact Number cannot be blank!");
                return false;
            }
            else{
                if (b.length > 10 || b.length < 10)
                    {
                alert("Error: Please enter a valid contact number!");
                return false;
                }
            }
            
              var e = document.forms["myForm"]["emailaddress"].value;
            if(e == '') {
                alert("Error: Email address connot be blank!");
                return false;
            } 
            else
            {
                var valid = false;
                for (i=0; i < e.length; i++)
                {   
                    if (e[i] == '@')
                    valid = true;
                }
                    if (!valid) 
                {
                    alert (" Error: Email address must contain a @");
                    return false;
                }
                   
                }
            
       }
</script>
     </head>
     <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>My Profile</h1>
                
                <hr />
                <div class="panel-body"> 



<form action='' name='myForm' method="GET" onsubmit="return validateForm()">
    <h3>Update Profile</h3>
<table>
<?php
	echo "Surname:<input type=text name=surname class=form-control value ='".$client->surname."'><br>

Initials:<input type=text name=initials class=form-control value ='".$client->initials."'><br>
ID No:<input type=text name=idno pattern='(\d{2})(0[123456789]|1[012])(0[123456789]|[12][0123456789]|3[01])(\d{4})([01])(8)(\d{1})' title='13 numeric characters required!' class=form-control value ='".$client->idno."'><br>
Contact No: <input type=text name=contactno pattern='0[786][01234567][0-9]{7}' title='10 numeric characters required!' class=form-control value ='".$client->contactno."'><br>
Email Address: <input type=text name=emailaddress pattern='\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*' title='Please enter a valid email address' class=form-control value ='".$client->emailaddress."'><br>
<input type=hidden name=controller value='client'>
<input type=hidden name=action value='myProfile'>

<input type=submit value=Update class=btn-default>

</form>";

?>
    </div>
            </div>
        </div>
     </div>
</html>
