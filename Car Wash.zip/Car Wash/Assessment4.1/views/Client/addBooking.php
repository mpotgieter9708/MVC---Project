<?php?>

<html>
    <title>New Booking</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
        function validateForm() {
            var x = document.forms["myForm"]["date"].value;
            var d = new Date();
            var year = d.getFullYear();
            var month = '' + (d.getMonth() + 1);
            var day = '' + d.getDate();
            
            if (month.length < 2) month = "0" + month;
            if (day.length < 2) day = "0" + day;
            var date = year + "-" + month + "-" + day;
            
            if (x < date) {
                alert("Error: Please select a valid booking date!");
                return false;
            }
             else {
                if (x >= date)
                {
                    return true;
                }
            }
       }
        </script>
     </head>
     
    
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>New Booking</h1>
                <hr />
                <div class="panel-body"> 
                    <?php $message ?>
        <form action='' name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='client'>
	<input type=hidden name=action value='addBooking'>
        Date: <input type="date" name="date" value="<?php echo $date; ?>" class="form-control"  pattern="(19|20)[1-9]{2}-[0-9]{2}-[0-9]{2}" title='Valid date example: 2018-01-01'/><br>
        Registration No: <select name="regno" class="form-control"><?php
            foreach($vehicle as $veh){
	echo "<option value='".$veh->regno."'>".$veh->regno."</option>";
        }?></select><br>
        Service Type: <select name="scode" class="form-control">
            <?php
            foreach($service as $serv){
	echo "<option value='".$serv->scode."'>".$serv->sdesc."</option>";
        }?>*/</select><br>
            Time:<select name="time" class="form-control">
                <option>08:00</option>
                <option>09:00</option>
                <option>10:00</option>
                <option>11:00</option>
                <option>12:00</option>
                <option>13:00</option>
                <option>14:00</option>
                <option>15:00</option>
                <option>16:00</option>
            </select><br>
            <input type="submit" value="Make Booking" class="btn-default"/>
        </form>
                </div>
            </div>
        </div>
   </div>
</html>


