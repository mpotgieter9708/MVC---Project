
<html>
    <title>Add New Vehicle</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <script>
        function validateForm() {
            var x = document.forms["myForm"]["regno"].value;
            if (x.length > 8 ) {
                alert("Error: Please enter a valid registration number!");
                return false;
            }
            else {
                if(x == '')
                {
                    alert("Error: Registration number cannot be blank!");
                    return false;
                }
            }
       }
</script>
    </head>
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>Add Vehicle </h1>
                <hr />
                <div class="panel-body"> 
                    <form action='' name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='client'>
	<input type=hidden name=action value='addVehicle'>
            
            
            
        Registration No:<input type="text" name="regno" value="" class="form-control" /><br>
             
            Make:<select name="make" class="form-control">
                            <option>--Select Make--</option>
                <option>Acura</option>
                <option>Abarth</option>
                <option>Abadal</option>
                <option>Aixam</option>
                <option>Alfa Romeo</option>
                <option>Audi</option>
                <option>Aston Marin</option>
                <option>Aixam</option>
                <option>Alta</option>
                <option>Alvis</option>
                <option>Alpina</option>
                <option>Arash</option>
                <option>Ariel</option>
                <option>Alta</option>
                <option>Axon</option>
                <option>Arrinera</option>
                <option>Atalanta</option>
                <option>BAC</option>
                <option>Baojun</option>
                <option>BAIC</option>
                <option>Berkeley</option>
                <option>Berliet</option>
                <option>Bertone</option>
                <option>Bedford</option>
                <option>Bolwell</option>
                <option>BharatNemz</option>
                <option>Bitter</option>
                <option>Bizzarrini</option>
                <option>BMW</option>
                <option>Borgward</option>
                <option>Bowler</option>
                <option>Brabus</option>
                <option>Brammo</option>
                <option>Brilliance</option>
                <option>Bristol</option>
                <option>Brooke</option>
                <option>Buick</option>
                <option>Bentley</option>
                <option>Bugatti</option>
                <option>Bufori</option>
                <option>BYD</option>
                <option>Caterham</option>
                <option>Carlsson</option>
                <option>Capro</option>
                <option>Changan</option>
                <option>Changfeng</option>
                <option>Chrysler</option>
                <option>Citroen</option>
                <option>Cisitalia</option>
                <option>Cizeta</option>
                <option>Cole</option>
                <option>Corre La Licorne</option>
                <option>Corvetta</option>
                <option>Cadillac</option>
                <option>Chevy</option>
                <option>Dacia</option>
                <option>Daewoo</option>
                <option>DAF</option>
                <option>Daihatsu</option>
                <option>Daimler</option>
                <option>Datsun</option>
                <option>David Brown</option>
                <option>Delage</option>
                <option>DMC</option>
                <option>De Tomaso</option>
                <option>Detroit Electric</option>
                <option>Diatto</option>
                <option>DINA</option>
                <option>Dongfeng</option>
                <option>DS</option>
                <option>Donkervoort</option>
                <option>Dodge</option>
                <option>Ferrari</option>
                <option>9ff</option>
                <option>Facel Vega</option>
                <option>Faradey Future</option>
                <option>FAW</option>
                <option>Fioravanti</option>
                <option>Fisker</option>
                <option>Fodon</option>
                <option>Foton</option>
                <option>Force Motors</option>
                <option>Fiat</option>
                <option>Ford</option>
                <option>FPV</option>
                <option>Franklin</option>
                <option>Freightliner</option>
                <option>GAC</option>
                <option>GAZ</option>
                <option>Genesis</option>
                <option>Geo</option>
                <option>Gilbern</option>
                <option>Gillet</option>
                <option>Ginetta</option>
                <option>Gonow</option>
                <option>Great Wall</option>
                <option>Grinnall</option>
                <option>GTA Motor</option>
                <option>GT-R</option>
                <option>Gumpert</option>
                <option>Hafei</option>
                <option>Haima</option>
                <option>Haval</option>
                <option>Hawtai</option>
                <option>Hennessey</option>
                <option>Hillman</option>
                <option>Hindustan Motors</option>
                <option>Hino</option>
                <option>Hispano-Suiza</option>
                <option>HSV</option>
                <option>Holden</option>
                <option>Hommel</option>
                <option>Honda</option>
                <option>Horch</option>
                <option>Hudson</option>
                <option>Humber</option>
                <option>Hummer</option>
                <option>Hupmobile</option>
                <option>Hyundai</option>
                <option>Isuzu</option>
                <option>Infiniti</option>
                <option>Innocenti</option>
                <option>Intermeccanica</option>
                <option>IH</option>
                <option>International</option>
                <option>IKCO</option>
                <option>Irizar</option>
                <option>Isdera</option>
                <option>Iso Rivolta</option>
                <option>Iveco</option>
                <option>Jeep</option>
                <option>Jaguar</option>               
                <option>Jawa</option>
                <option>Jensen</option>                            
                <option>Kamaz</option>
                <option>Keating</option>
                <option>Kenworth</option>
                <option>Kia</option>
                <option>KTM</option>
                <option>Landwind</option>
                <option>Laraki</option>
                <option>Lada</option>
                <option>LEVC</option>
                <option>Leyland</option>
                <option>Lifan</option>
                <option>Ligier</option>
                <option>Lincoln</option>
                <option>Lexus</option>
                <option>Lagonda</option>
                <option>Land Rover</option>
                <option>Lancia</option>
                <option>Lamborghini</option>        
                <option>Lister</option>
                <option>Lloyd</option>
                <option>Lobin</option>
                <option>Lotus</option>
                <option>Lucid</option>
                <option>Luxgen</option>
                <option>Mack</option>
                <option>Mahindra</option>
                <option>MAN</option>
                <option>Mansory</option>
                <option>Marcos</option>
                <option>Marlin</option>
                <option>Maserati</option>
                <option>Mastretta</option>
                <option>Maxus</option>
                <option>Maybach</option>
                <option>MAZ</option>
                <option>Mazda</option>
                <option>Mazzanti</option>
                <option>BMW</option>
                <option>Melkus</option>
                <option>Mercury</option>
                <option>McLaren</option>
                <option>Mercedes-Benz</option>
                <option>Merkur</option>
                <option>MEV</option>
                <option>MG</option>
                <option>Microcar</option>
                <option>Mitsuoka</option>
                <option>MK</option>
                <option>Morgan</option>
                <option>Morris</option>
                <option>Mosler</option>
                <option>Mustang</option>
                <option>Mercedes Benz</option>
                <option>MG Motor</option>
                <option>Microcar</option>
                <option>Mini</option>
                <option>Mitsubishi</option>
                <option>Navistar</option>
                <option>Nismo</option>
                <option>Noble</option>
                <option>Nissan</option>
                <option>Oldsmobile</option>
                <option>Oltcit</option>
                <option>OSCA</option>
                <option>Opel</option>
                <option>Paccar</option>
                <option>Panhard</option>
                <option>Pegaso</option>
                <option>Perodua</option>
                <option>Peterbilt</option>
                <option>PGO</option>
                <option>Pierce-Arrow</option>
                <option>Pininfarina</option>
                <option>Playmouth</option>
                <option>Polestar</option>
                <option>Pontiac</option>
                <option>Praga</option>
                <option>Prodrive</option>
                <option>Porsche</option>
                <option>Pontiac</option>
                <option>Qoros</option>
                <option>Radical</option>
                <option>Rambler</option>
                <option>Ram</option>
                <option>Renault</option>
                <option>Rolls Royce</option>
                <option>Rezvani</option>
                <option>Riley</option>
                <option>Rimac</option>
                <option>Rinspeed</option>
                <option>Ronart</option>
                <option>Rossion</option>
                <option>RUF</option>
                <option>Saipa</option>
                <option>Saleen</option>
                <option>Saturn</option>
                <option>Scion</option>
                <option>Seat</option>
                <option>Setra</option>
                <option>Shelby</option>
                <option>Simca</option>
                <option>Singer</option>
                <option>Sisu Auto</option>
                <option>Skoda</option>
                <option>Soueast</option>
                <option>Spirra</option>
                <option>SRT</option>
                <option>SsangYong</option>
                <option>SSC</option>
                <option>Sterling</option>
                <option>Studebaker</option>
                <option>Subaru</option>
                <option>Suffolk</option>
                <option>SMART</option>
                <option>Suzuki</option>
                <option>Talbot</option>
                <option>Tauro Sport Auto</option>                                     
                <option>Tatra</option>
                <option>Tata</option>
                <option>TechArt</option>
                <option>Tesla</option>
                <option>Toyota</option>
                <option>Tramontana</option>
                <option>Trion</option>
                <option>Triumph</option>
                <option>Troller</option>
                <option>TVR</option>
                <option>UAZ</option>
                <option>UD</option>
                <option>Ultima</option>
                <option>Vandenbrink</option>
                <option>Vauxhall</option>
                <option>Vencer</option>
                <option>Vector</option>
                <option>Venturi</option>
                <option>Venucia</option>
                <option>Volkswagen</option>
                <option>Volve</option>
                <option>Wanderer</option>
                <option>Wartburg</option>
                <option>Western Star</option>
                <option>Westfield</option>
                <option>Wiesmann</option>
                <option>Willys</option>
                <option>W Motors</option>
                <option>Wuling</option>
                <option>Yulon</option>
                <option>Zastava</option>
                <option>ZAZ</option>
                <option>Zenos</option>
                <option>Zotye</option>
                <option>GMC</option>
                <option>Sunbeam</option>
                <option>Geely</option>
                <option>Saab</option>
                <option>Proton</option>
                <option>Lada</option>
                <option>Roewe</option>
                <option>Spyker</option>
                <option>Geely</option>
                <option>Koenigsegg</option>
                <option>Pagani</option>
                                          
                    </select><br>
                Model:<select name="model" class="form-control">
                            <option>--Select Model--</option>
                <option>Anglia</option>
                <option>Bronco</option>
                <option>Capri</option>
                <option>Cobra</option>
                <option>Consul</option>
                <option>Corsair</option>
                <option>Cortina</option>
                <option>Cougar</option>
                <option>Courier</option>
                <option>Econovan</option>
                <option>EcoSport</option>
                <option>Endura</option>  
                <option>Escape</option>   
                <option>Escort</option>   
                <option>Everest</option>
                <option>Explorer</option>
                <option>F100</option>
                <option>F150</option>
                <option>F250</option>
                <option>F350</option>
                <option>Fairlane</option>
                <option>Fairmont</option>
                <option>Falcon</option>
                <option>Falcon Ute</option>
                <option>Festiva</option>
                <option>Fiesta</option>
                <option>Focus</option>
                <option>Galaxie</option>
                <option>KA</option>
                <option>Kuga</option>
                <option>Landau</option>
                <option>Laser</option>
                <option>LTD</option>
                <option>Maverick</option>
                <option>Meteor</option>
                <option>Mondeo</option>
                <option>Mustang</option>
                <option>Prefect</option>
                <option>Probe</option>
                <option>Raider</option>
                <option>Ranger</option>
                <option>Spectron</option>
                <option>Taurus</option>
                <option>TE50</option>
                <option>Telstar</option>
                <option>Territory</option>
                <option>TL50</option>
                <option>Transit</option>
                <option>Transit Custom</option>
                <option>TS50</option>
                <option>Zephyr</option>
                <option>Zodiac</option>
                <option>Adventra</option>
                <option>Apollo</option>
                <option>Astra</option>
                <option>Barina</option>
                <option>Barina Spark</option>
                <option>Calais</option>
                <option>Calibra</option>
                <option>Camira</option>
                <option>Caprice</option>
                <option>Captiva</option>
                <option>Cascada</option>
                <option>Colorado</option>
                <option>Colorado 7</option>
                <option>Combo</option>
                <option>Commodore</option>
                <option>Crewman</option>
                <option>Cruze</option>
                <option>Drover</option>
                <option>Epica</option>
                <option>Equinox</option>
                <option>Frontera</option>
                <option>Gemini</option>
                <option>Insignia</option>
                <option>Jackaroo</option>
                <option>Malibu</option>
                <option>Monaro</option>
                <option>Nova</option>
                <option>Piazza</option>
                <option>Rodeo</option>
                <option>Scurry</option>
                <option>Shuttlev</option>
                <option>Spark</option>
                <option>Statesman</option>
                <option>Suburban</option>
                <option>Sunbird</option>
                <option>Tigra</option>
                <option>Torana</option>
                <option>Trailerblazer</option>
                <option>Traxv</option>
                <option>Ute</option>
                <option>Vectra</option>
                <option>Viva</option>
                <option>Volt</option>
                <option>Zafira</option>
                <option>1300</option>
                <option>600</option>
                <option>Accord</option>
                <option>Accord Euro</option>
                <option>Acty</option>
                <option>City</option>
                <option>Civic</option>
                <option>Concerto</option>
                <option>CR-V</option>
                <option>CR-Z</option>
                <option>HR-V</option>
                <option>Insight</option>
                <option>Integra</option>
                <option>Jazz</option>
                <option>Legend</option>
                <option>Life</option>
                <option>MDX</option>
                <option>N360</option>
                <option>NSX</option>
                <option>Odyssey</option>
                <option>Prelude</option>
                <option>S2000</option>
                <option>S600</option>
                <option>S800</option>
                <option>z</option>
                <option>Accent</option>
                <option>Elantra</option>
                <option>Elantra Lavita</option>
                <option>Excel</option>
                <option>Genesis</option>
                <option>Getz</option>
                <option>Grandeur</option>
                <option>i10</option>
                <option>i20</option>
                <option>i30</option>
                <option>i45</option>
                <option>iLoad</option>
                <option>iMax</option>
                <option>iX35</option>
                <option>Kona</option>
                <option>Lantra</option>
                <option>Nexo</option>
                <option>Santa Fe</option>
                <option>Sonata</option>
                <option>Terracan</option>
                <option>Tiburon</option>
                <option>Trajet</option>
                <option>Tucson</option>
                <option>Veloster</option>
                <option>Kona</option>
                <option>1000</option>
                <option>1200</option>
                <option>121</option>
                <option>1300</option>
                <option>1500</option>
                <option>1800</option>
                <option>Mazda2</option>
                <option>Mazda3</option>
                <option>323</option>
                <option>Mazda6</option>
                <option>600</option>
                <option>626</option>
                <option>800</option>
                <option>808</option>
                <option>929</option>
                <option>B1500</option>
                <option>B1600</option>
                <option>B1800</option>
                <option>B2000</option>                      
                <option>B2200</option>
                <option>B2500</option>
                <option>B2600</option>
                <option>B4000</option>
                <option>BT-50</option>
                <option>Capella</option>
                <option>CX-3</option>
                <option>CX-5</option>
                <option>CX-7</option>
                <option>CX-8</option>
                <option>CX-9</option>
                <option>E1300</option>
                <option>E1400</option>
                <option>E1600</option>
                <option>E1800</option>
                <option>E2000</option>
                <option>E2200</option>
                <option>E2500</option>
                <option>E3000</option>
                <option>E4100</option>
                <option>F1000</option>
                <option>MPV</option>
                <option>MX-5</option>
                <option>MX-6</option>
                <option>Premacy</option>
                <option>R100</option>
                <option>RX-4</option>
                <option>RX-5</option>
                <option>RX-7</option>
                <option>RX-8</option>
                <option>Traveller</option>
                <option>Tribute</option>
                <option>380</option>
                <option>ASX</option>
                <option>Challenger</option>
                <option>Colt</option>
                <option>Cordia</option>
                <option>D50</option>
                <option>Eclipse</option>
                <option>Express</option>
                <option>Galant</option>
                <option>Grandis</option>
                <option>i-MiEV</option>
                <option>Lancer</option>
                <option>Magna</option>
                <option>Mirage</option>
                <option>Nimbus</option>
                <option>Outlander</option>
                <option>Pajero</option>
                <option>Pajero Sport</option>
                <option>Sigma</option>
                <option>Starion</option>
                <option>Triton</option>
                <option>Verada</option>
                <option>120Y</option>
                <option>350Z</option>                                           
                <option>Almera</option>
                <option>Altima</option>
                <option>Bluebird</option>
                <option>C20</option>
                <option>Cabstar</option>
                <option>Cedrick</option>
                <option>Cube</option>
                <option>Dualis</option>
                <option>E20</option>
                <option>EXA</option>
                <option>Gazelle</option>
                <option>GT-R</option>
                <option>Homer</option>
                <option>Juke</option>
                <option>Leaf</option>
                <option>Maxima</option>
                <option>Micra</option>
                <option>Murano</option>
                <option>Navara</option>
                <option>Nomad</option>
                <option>NX</option>
                <option>Pathfinder</option>
                <option>Patrol</option>
                <option>Pintara</option>
                <option>Pulsar</option>
                <option>Qashqai</option>
                <option>Serena</option>
                <option>Skyline</option>
                <option>Stanza</option>
                <option>Sunny</option>
                <option>UTE</option>
                <option>Tiida</option>
                <option>Urvan</option>
                <option>V30</option>
                <option>Vanette</option>
                <option>X-Trail</option>
                <option>Brumby</option>
                <option>BRZ</option>
                <option>FF -1</option>
                <option>Fiori</option>
                <option>Forester</option>
                <option>Impreza</option>
                <option>Leone</option>   
                <option>Levorg</option>
                <option>Liberty</option> 
                <option>Outback</option>         
                <option>Sherpa</option>  
                <option>SVX</option> 
                <option>Tribeca</option>
                <option>WRX</option>
                <option>XV</option>
                <option>4Runner</option>
                <option>86</option>
                <option>Aurion</option>
                <option>Avalon</option>
                <option>Avensis</option>
                <option>Blizzard</option>
                <option>Bundera</option>
                <option>C-HR</option>
                <option>Camry</option>
                <option>Celica</option>
                <option>Corrolla</option>
                <option>Corona</option>
                <option>Cressida</option>
                <option>Crown</option>
                <option>Dyna</option>
                <option>Echo</option>
                <option>FJ Cruiser</option>
                <option>Fortuner</option>
                <option>HiAce</option>
                <option>HiLux</option>
                <option>Kluger</option>
                <option>Land Cruiser</option>
                <option>Land Cruiser Prado</option>
                <option>Lexcen</option>
                <option>MR2</option>
                <option>Paseo</option>
                <option>Prius</option>
                <option>Prius C</option>
                <option>Prius V</option>
                <option>RAV4</option>
                <option>Rukus</option>  
                <option>Spacia</option> 
                <option>Sprinter</option>   
                <option>Starlet</option> 
                <option>Stout</option>
                <option>Supra</option>   
                <option>T-18</option>
                <option>Tarago</option>  
                <option>Tercel</option>
                <option>Tiara</option>
                <option>TownAce</option>
                <option>Toyoace</option>
                <option>Vienta</option>
                <option>Yaris</option>
                <option>Amarok</option>
                <option>Arteon</option>
                <option>Beetle</option>
                <option>Bora</option>
                <option>Caddy</option>
                <option>Caravelle</option>
                <option>CC</option>
                <option>Citivan</option>
                <option>Eos</option>
                <option>Golf</option>
                <option>Jetta</option>
                <option>Kombi</option>
                <option>Multivan</option>
                <option>Passat</option>
                <option>Polo</option>
                <option>Scirocco</option>
                <option>Tiguan</option>
                <option>Touareg</option>
                <option>Transporter</option>
                <option>Up!</option>
                <option>Vento</option>
                <option>100</option>
                <option>200</option>
                <option>5E</option>
                <option>80</option>
                <option>90</option>
                <option>A1</option>
                <option>A2</option>
                <option>A3</option>
                <option>A4</option>
                <option>A5</option>
                <option>A6</option>
                <option>A7</option>
                <option>A8</option>
                <option>Quattro</option>
                <option>Cabriolet</option>
                <option>Fox</option>
                <option>Q2</option>
                <option>Q3</option>
                <option>Q5</option>
                <option>Q7</option>
                <option>R8</option>
                <option>RS Q3</option>
                <option>RS3</option>
                <option>RS4</option>
                <option>RS5</option>
                <option>RS6</option>
                <option>RS7</option>
                <option>S1</option>
                <option>S2</option>
                <option>S3</option>
                <option>S4</option>
                <option>S5</option>
                <option>S6</option>
                <option>S7</option>
                <option>S8</option>
                <option>SQ5</option>
                <option>SQ7</option>
                <option>TT</option>
                <option>V8 Quattro</option>
                <option>1 Series</option>
                <option>2 Series</option>
                <option>3 Series</option>
                <option>4 Series</option>
                <option>5 Series</option>
                <option>6 Series</option>
                <option>7 Series</option>
                <option>i3</option>
                <option>i8</option>
                <option>M2</option>
                <option>M3</option>
                <option>M4</option>
                <option>M5</option>
                <option>M6</option>
                <option>X1</option>
                <option>X2</option>
                <option>X3</option>
                <option>X4</option>
                <option>X5</option>
                <option>X6</option>
                <option>X7</option>
                <option>Z3</option>
                <option>Z4</option>
                <option>DB11</option>
                <option>DB4</option>
                <option>DB5</option>
                <option>DB6</option>
                <option>DB9</option>
                <option>DBS</option>
                <option>Lagonda</option>
                <option>Rapide</option>
                <option>V12</option>
                <option>V8</option>
                <option>Vanquish</option>
                <option>Vantage</option>
                <option>Virage</option>
                <option>Veyron</option>
                <option>C20</option>
                <option>C30</option>
                <option>Camaro</option>
                <option>Corvette</option>
                <option>Impala</option>
                <option>Silverado</option>
                <option>300</option>
                <option>300C</option>
                <option>Centura</option>
                <option>Charger</option>
                <option>Chyrysler</option>
                <option>Crossfire</option>
                <option>Galant</option>
                <option>Grand Voyager</option>
                <option>Lancer</option>
                <option>Neon</option>
                <option>PT Cruiser</option>
                <option>Regal</option>
                <option>Royal</option>
                <option>Sebring</option>
                <option>Valiant</option>
                <option>Viper</option>
                <option>Voyager</option>
                <option>AX</option>
                <option>Berlingo</option>
                <option>BX</option>
                <option>C2</option>
                <option>C3</option>
                <option>C4</option>
                <option>C4 Aircross</option>
                <option>C4 Cactus</option>
                <option>C4 Picasso</option>
                <option>C5</option>
                <option>C6</option>
                <option>CX</option>
                <option>D</option>
                <option>Dispatch</option>
                <option>DS</option>
                <option>DS3</option>
                <option>DS45</option>
                <option>G</option>
                <option>grand C4 Picasso</option>
                <option>GS</option>
                <option>ID</option>
                <option>Xantia</option>
                <option>XM</option>
                <option>Xsara</option>
                <option>360X</option>
                <option>Applause</option>
                <option>Charade</option>
                <option>Compagno</option>
                <option>Copen</option>
                <option>Cuore</option>
                <option>F20</option>
                <option>F25</option>
                <option>F50</option>
                <option>F55</option>
                <option>F60</option>
                <option>Feroza</option>
                <option>Handi</option>
                <option>Mira</option>
                <option>Move</option>
                <option>Pyzar</option>
                <option>Rocky</option>
                <option>S60</option>
                <option>S65</option>
                <option>Sirion</option>
                <option>Terios</option>
                <option>YRV</option>
                <option>Bluebird</option>
                <option>Fairlady</option>
                <option>GT</option>
                <option>Patrol</option>
                <option>Silvia</option>
                <option>Sunny</option>
                <option>Vengar</option>
                <option>Caliber</option>
                <option>Journey</option>
                <option>Nitro</option>
                <option>Phoenix</option>
                <option>California</option>
                <option>Dino</option>
                <option>Mondial</option>
                <option>Superamerica</option>>
                <option>Argenta</option>
                <option>Croma</option>
                <option>Ducato</option>
                <option>Freemont</option>
                <option>Panda</option>
                <option>Punto</option>
                <option>Regata</option>
                <option>Ritmo</option>
                <option>Scudo</option>
                <option>Superbrava</option>
                <option>X1/9</option>
                <option>MK</option>
                <option>A-Class</option>
                <option>B-Class</option>
                <option>C-Class</option>
                <option>CL-Class</option>
                <option>CLA-Class</option>
                <option>CLC-Class</option>
                <option>CLK-Class</option>
                <option>CLS-Class</option>
                <option>E-Class</option>
                <option>G-Class</option>
                <option>GL-Class</option>
                <option>GLA-Class</option>
                <option>GLC-Class</option>
                <option>GLE-Class</option>
                <option>GLS-Class</option>
                <option>M Class</option>
                <option>Marco Polo</option>
                <option>R-Class</option>
                <option>S-Class</option>
                <option>SL-Class</option>
                <option>SLK-Class</option>
                <option>SLS</option>
                <option>V-Class</option>
                <option>Valente</option>
                <option>Viano</option>
                <option>Vito</option>
                <option>X-Class</option>
                <option>E-Pace</option>
                <option>F-Pace</option>
                <option>F-Type</option>
                <option>I-Pace</option>
                <option>Majestic</option>
                <option>Mk II</option>
                <option>Mk IX</option>
                <option>Mk X</option>
                <option>Sovereign</option>
                <option>V12</option>
                <option>Vanden Plas</option>
                <option>XE</option>
                <option>XF</option>
                <option>XJ</option>
                <option>XJ12</option>
                <option>XJ6</option>
                <option>XJ8</option>
                <option>XJR</option>
                <option>XJS</option>
                <option>XK</option>
                <option>XK8</option>
                <option>XKR</option>
                <option>Carens</option>
                <option>Carnival</option>
                <option>Cerato</option>
                <option>Grand Carnival</option>
                <option>K2700</option>
                <option>K2900</option>
                <option>Magentis</option>
                <option>Mentor</option>
                <option>Optima</option>
                <option>Picanto</option>
                <option>Pregio</option>
                <option>Pro_cee'd GT</option>
                <option>Rio</option>
                <option>Rondo</option>
                <option>Shuma</option>
                <option>Sorento</option>
                <option>Soul</option>
                <option>Spectra</option>
                <option>Sportage</option>
                <option>Stinger</option>
                <option>Aventador</option>
                <option>Countach</option>
                <option>Diablo</option>
                <option>Espada</option>
                <option>Gallardo</option>
                <option>Huracan</option>
                <option>Islero</option>
                <option>Jalpa</option>
                <option>Jarama</option>
                <option>Miura</option>
                <option>Murcielago</option>
                <option>Silhouette</option>
                <option>Urraco</option>
                <option>Urus</option>
                <option>Defender</option>
                <option>Discovery</option>
                <option>Discovery 3</option>
                <option>Discovery 4</option>
                <option>Discovery Sport</option>
                <option>Freelander</option>
                <option>Freelander 2</option>
                <option>Range Rover</option>
                <option>Range Rover Evoque</option>
                <option>Range Rover Sport</option>
                <option>Range Rover Velar</option>
                <option>Range Rover Vogue</option>
                <option>CT</option>
                <option>ES</option>
                <option>GS</option>
                <option>GS -F</option>
                <option>GS200t</option>
                <option>IS</option>
                <option>IS200t</option>
                <option>LC</option>
                <option>LC500</option>
                <option>LC500h</option>
                <option>LFA</option>
                <option>LS</option>
                <option>LX</option>
                <option>NX</option>
                <option>RC</option>
                <option>RC200t</option>
                <option>RX</option>
                <option>RX200t</option>
                <option>SC</option>
                <option>UX</option>
                <option>Bushranger</option>
                <option>Genio</option>
                <option>Pik-Up</option>
                <option>Stockman</option>
                <option>XUV500</option>                                          
                <option>Clubman</option>
                <option>Convertible</option>
                <option>Cooper</option>
                <option>Countryman</option>
                <option>Coupe</option>
                <option>Paceman</option>
                <option>Roadster</option>
                <option>57</option>
                <option>62</option>
                <option>570s</option>
                <option>600LT</option>
                <option>650S</option>
                    </select><br>
                          Colour:<br><!--<select name="colour" class="form-control">-->
                           <br><input type="radio" name="colour" value="White" checked />White<br>
                            <input type="radio" name="colour" value="Cream" />Cream<br>
                            <input type="radio" name="colour" value="Silver" />Silver<br>
                            <input type="radio" name="colour" value="Grey" />Grey<br>
                            <input type="radio" name="colour" value="Brown" />Brown<br>
                            <input type="radio" name="colour" value="Black" />Black<br>
                            <input type="radio" name="colour" value="Red" />Red<br>
                            <input type="radio" name="colour" value="Blue" />Blue<br>
                            <input type="radio" name="colour" value="Yellow" />Yellow<br>
                            <input type="radio" name="colour" value="Orange" />Orange<br>
                            <input type="radio" name="colour" value="Green" />Green<br>
                            <input type="radio" name="colour" value="Purple" />Purple<br>
                            <input type="radio" name="colour" value="Pink" />Pink<br><br>
                            
                           <!--<option>--Select Colour--</option>
                <option>White</option>
                <option>Cream</option>
                <option>Silver</option>
                <option>Beige</option>
                <option>Brown</option>
                <option>Black</option>
                <option>Red</option>
                <option>Maroon</option>
                <option>Blue</option>
                <option>Orange</option>
                <option>Yellow</option>
                <option>Green</option>
                <option>Purple</option>
                <option>Pink</option>
                <option>Grey</option>
            </select>-->
                Year:<select name="year" class="form-control">
                <option>--Select Year--</option>
                <option Value="2018">2018</option>
                <option Value="2017">2017</option>
                <option Value="2016">2016</option>
                <option Value="2015">2015</option>
                <option Value="2014">2014</option>
                <option Value="2013">2013</option>
                <option Value="2012">2012</option>
                <option Value="2011">2011</option>
                <option Value="2010">2010</option>
                <option Value="2009">2009</option>
                <option Value="2008">2008</option>
                <option Value="2007">2007</option>
                <option Value="2006">2006</option>
                <option Value="2005">2005</option>
                <option Value="2004">2004</option>
                <option Value="2003">2003</option>
                <option Value="2002">2002</option>
                <option Value="2001">2001</option>
                <option Value="2000">2000</option>
                <option Value="1999">1999</option>
                <option Value="1998">1998</option>
                <option Value="1997">1997</option>
                <option Value="1996">1996</option>
                <option Value="1995">1995</option>
                <option Value="1994">1994</option>
                <option Value="1993">1993</option>
                <option Value="1992">1992</option>
                <option Value="1991">1991</option>
                <option Value="1990">1990</option>
                <option Value="1989">1989</option>
                <option Value="1988">1988</option>
                <option Value="1987">1987</option>
                <option Value="1986">1986</option>
                <option Value="1985">1985</option>
                <option Value="1984">1984</option>
                     </select><br>
                <input type="submit" value="Add Vehicle" class="btn-default"/>
            </form>
                    
                    
    </div>
        </div>
        </div>
    </div>
    </body>
</html>

