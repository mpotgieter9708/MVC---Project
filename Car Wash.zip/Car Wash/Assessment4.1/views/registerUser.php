<html>
    <title>Register</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <script>
        function checkForm(form)
        {
            if(form.username.value == "") {
            alert("Error: Username cannot be blank!");
            form.username.focus();
            return false;
         }
            re = /^\w+$/;
            if(!re.test(form.username.value)) {
            alert("Error: Username must contain only letters, numbers and underscores!");
            form.username.focus();
            return false;
            }
            
            if(form.userpassword.value.length < 6) {
            alert("Error: Password must contain at least six characters!");
            form.userpassword.focus();
            return false;
            }
         
    }
</script>
     </head>
     
    <body>
        <div class="navbar">
            <a href="Default.php"><i class="fa fa-home"></i>Home</a>
            <div class="navbar-right">
                <a href="index.php">Log in<i class="fa fa-sign-in"></i></a>
            </div>
  </div>
        <br>
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
               
               
                <div class="panel-body">
                    <h4>Register Log In Details</h4>
                    <form action="" method="POST" onsubmit="return checkForm(this);">
                        <input type=hidden name=controller value=register><input type=hidden name=action value=registerUser>
                        User name:<input type="text" name="username" value="" class="form-control"/><br>
                        Password:<input type="password" name="userpassword" value="" class="form-control"/> <br>
                        <input type="submit" value="Register" class="btn-default"/>
                        <br><br>Already have a local account <a href="index.php">Log in<i class="fa fa-sign-in"></i></a>
                    </form>

