<html>
    <title>Customer Promotion Report</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-5 col-md-offset-3">
            
            <div class="panel panel-default panel-background">
                <h1>Customer Promotion Report</h1>
                <hr />
                <div class="panel-body">
                    <p>Customers which cars were washed 5 times:</p>
<?php
//echo "Today is " . date("Y/m/d") . "<br>";
//echo "Today is " . date("Y.m.d") . "<br>";
//echo "Today is " . date("Y-m-1") . "<br>";
//echo "Today is " . date("l");
?>
<?php

echo "<form method = GET><table border=1><tr>
<th>Customer Name</th><th>Registration No</th><th>Contact No</th><th>Email Address</th><th>Total</th>
</tr>";
foreach ($promotion as $promo)
{
echo "<tr>
    
<td>$promo->surname, $promo->initials</td>

    <td>$promo->regno</td>
    <td>$promo->contactno</td>
    <td>$promo->emailaddress</td>
        <td>$promo->total</td>
           
                
            
</tr>";
    
}
?>
</table></form>

<?php
echo "<input type=hidden name=controller value = manager>";
echo "<input type=hidden name=action value = promotionReport>";

?>
                </div>
            </div>
        </div>
     </div>
                    
</html>






