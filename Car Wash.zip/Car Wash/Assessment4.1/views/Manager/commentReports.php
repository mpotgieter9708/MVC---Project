<html>
    <title>Customer Comment Report</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-8 col-md-offset-2">
            
            <div class="panel panel-default panel-background">
                <h1>Customer Comment Report</h1>
                <hr />
                <div class="panel-body"> 

<?php
/************************************************************************
* This page is used to display a list of subjects for a lecturer
************************************************************************/

// start with the dropdown that is populated with subject code and name

//echo "<h1>All Employees<h1>";
echo "<form name=form1 method = GET>Please Select Employee:<select name = empno class = 'form-control' onchange='form1.submit();'>";
echo "<option value='%'>All Employees</option>";
foreach ($employee as $emp) {
if ($emp->empno == $empno)
	$selected = ' Selected';
else $selected = '';

echo "<option value = ".$emp->empno.$selected.">".$emp->surname.",".$emp->initials."</option>";
}
?>
                    
</select>

<br>Select Start Date:<input type="date" name="date1" value="<?php echo $date1; ?>" class="form-control"/>

                         
<br>Select End Date:<input type="date" name="date2" value="<?php echo $date2; ?>" class="form-control"/>
                       


 <?php
echo "<input type=hidden name=controller value = manager>";
echo "<input type=hidden name=action value = commentReport>";

?>
</form> 
<?php if ($comment) { ?>
    <table border=1>
    
<tr><th>Comment Description</th><th >Booking Date</th><th>Employee Name</th><th>Registration No</th><th>Customer Name</th><th>Contact No</th><th>Service Description</th>
</tr>
<?php
foreach ($comment as $com)
{
echo "<tr>
    
<td>$com->description</td>
<td>$com->date </td>
    <td>$com->empSurname, $com->empInitials</td>
   
        <td>$com->regno</td>
            <td>$com->clSurname, $com->clInitials</td>
                
                    <td>$com->contactNo
                    <td>$com->sdesc</td>
                        
            
</tr>";
    
}
}
?>
</table>

                </div>
            </div>
        </div>
            </div>
     </div>
                    
</html>






