<?php?>

<html>
    <title>Assign Jobs</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     
    
   <div class="row">
        <div class="col-md-6 col-md-offset-3">
            
            <div class="panel panel-default panel-background">
                <h1>Assign Jobs</h1>
                <hr />
                <div class="panel-body"> 
        <form action='' method=GET><input type=hidden name=controller value='manager'>
	<input type=hidden name=action value='assignJob'>
        
                        
        <table>
            <tr> <th>Job Card No</th><th>Date</th><th>Time</th><th>Registration No</th><th>Employee Name</th></tr>
            <?php foreach ($allEmpBooking as $booking) {
echo "<tr>
<td><input type='text' name='jobcardno' value='".$booking->jobcardno."' class='form-control'/></td>
<td>$booking->date</td>
<td>$booking->time</td>
    <td>$booking->regno</td>
   
        <td><select name='empno' class = 'form-control'>
<option value = '".$booking->empno."'>".$booking->surname.", ".$booking->initials."</option>
    <option value = 1 > Bosch,H</option>
    <option value = 2 > Groenewald, H</option>
    <option value = 3 > Mofonkeng, PN</option>
    <option value = 4 > Potgieter, HG</option>
    <option value = 5 > Reitz, C</option>
    <option value = 6 > Reitz, D</option>
    <option value = 7 > Mabena, HJ</option>
    <option value = 8 > Potgieter, GE</option>
    <option value = 9 > Mofolo, J</option>
    <option value = 10 > Oosthuizen, F</option>
    <option value = 11 > Mathews, M</option>
    
            
</select></td>
        
    
   

        
<td><input type='submit' value='Update' class = 'btn-default'/> </td>           
</tr>";
}?>
        </table>
        
              </form>

                </div>
            </div>
        </div>
   </div>
</html>

