<html>
    <title>Invoice Report</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-8 col-md-offset-2">
            
            <div class="panel panel-default panel-background">
                <h1>Invoice Report</h1>
                <hr />
                <div class="panel-body"> 

<form name=form1 method = GET onchange='form1.submit();'>
    
  <br>Select Start Date:<input type="date" name="date1" value="<?php echo $date1; ?>" class="form-control"/>

                         
<br>Select End Date:<input type="date" name="date2" value="<?php echo $date2; ?>" class="form-control"/>


<?php
echo "<input type=hidden name=controller value = manager>";
echo "<input type=hidden name=action value = invoiceReport>";

?>
</form>
   <?php if ($invoiceR) { ?>
    <table border=1>
    
<tr><th>Invoice No</th><th >Invoice Date</th><th>Registration No</th><th>Booking Date</th><th>Booking Time</th><th>Customer Name</th><th>Service Description</th><th>Service Price</th>
</tr>
<?php
foreach ($invoiceR as $inv)
{
echo "<tr>
    
<td>$inv->ino</td>
<td>$inv->idate </td>
    <td>$inv->regno</td>
    <td>$inv->date</td>
        <td>$inv->time</td>
            <td>$inv->clsurname,$inv->clinitials</td>
                
                    <td>$inv->sdesc</td>
                        <td>$inv->sprice</td>
            
</tr>";
    
}
   }
?>
    </table><br>
<?php
foreach ($total as $invT)
{
echo 'Total Invoices Between '.$date1.' And '.$date2.': '.$invT->count.'';
}
?>

                </div>
            </div>
        </div>
     </div>
                    
</html>






