<?php?>

<html>
    <title>All Services</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     
    
   <div class="row">
        <div class="col-md-5 col-md-offset-3">
            
            <div class="panel panel-default panel-background">
                <h1>All Services</h1>
                <hr />
                <div class="panel-body"> 
      <form action='' method=GET><input type=hidden name=controller value='manager'>
        <input type=hidden name=action value='deleteService' >  
         <table>
            <tr> <th>Service Code</th><th>Service Description</th><th>Service Price</th></tr>
            <?php foreach ($service as $serv) {
echo "<tr>
<td><input type='text' name='scode' value='".$serv->scode."' class='form-control'/></td>
<td><input type='text' name='sdesc' value='".$serv->sdesc."' class='form-control'/></td>
    <td><input type='text' name='sprice' value='".$serv->sprice."' class='form-control'/></td>
     <td><input type='submit' value='Delete' class='btn-default'/></td>  
</tr>";
}?>
        </table>
        
        
        </form>
                </div>
            </div>
        </div>
   </div>
</html>


