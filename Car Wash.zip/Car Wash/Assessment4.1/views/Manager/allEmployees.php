<html>
    <title>All Employees</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>All Employees <i class="fa fa-group"></i></h1>
                <hr />
                <div class="panel-body"> 

<?php
/************************************************************************
* This page is used to display a list of subjects for a lecturer
************************************************************************/

// start with the dropdown that is populated with subject code and name

//echo "<h1>All Employees<h1>";
echo "<form method = GET><table border=1><tr>
<th>Employee No</th><th> Surname</th><th>Firstname</th><th>Initials</th><th>ID no</th><th>Date Appointed</th><th>Job Description</th>
</tr>";
foreach ($employee as $emp)
{
echo "<tr>
    
<td>$emp->empno</td>
<td>$emp->surname </td>
    <td>$emp->firstname</td>
    <td>$emp->initials</td>
        <td>$emp->idno</td>
            <td>$emp->dateappointed</td>
                <td>$emp->jobdesc</td>
            
</tr>";
    
}
?>
</table></form>

<?php
echo "<input type=hidden name=controller value = manager>";
echo "<input type=hidden name=action value = showAllEmployees>";

?>
                </div>
            </div>
        </div>
     </div>
                    
</html>






