<html>
    <title>Weekly Booking Report</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     <div class="row">
        <div class="col-md-6 col-md-offset-3">
            
            <div class="panel panel-default panel-background">
                <h1>Weekly Bookings</h1>
                <hr />
                <div class="panel-body"> 

<form name=form1 method = GET onchange='form1.submit();'>
    
  <br>Select Start Date:<input type="date" name="date1" value="<?php echo $date1; ?>" class="form-control"/>

                         
<br>Select End Date:<input type="date" name="date2" value="<?php echo $date2; ?>" class="form-control"/>


<?php
echo "<input type=hidden name=controller value = manager>";
echo "<input type=hidden name=action value = weeklyBookingReport>";

?>
</form> 
                    <?php if ($booking) { ?>
    <table border=1>
    
<tr><th>Booking No</th><th>Booking Date</th><th>Booking Time</th><th>Registration No</th><th>Customer Name</th><th>Service Description</th><th >Service Price</th>
</tr>
<?php
foreach ($booking as $book)
{
echo "<tr>
    
<td>$book->jobcardno</td>
<td>$book->date </td>
    <td>$book->time</td>
    <td>$book->regno</td>
        <td>$book->surname, $book->initials</td>
            <td>$book->sdesc</td>
                <td>$book->sprice</td>
                    
                    
        
            
</tr>";
    
}
                    }
?>
</table>
<br>
<?php
foreach ($total as $invT)
{
echo 'Total Bookings Between '.$date1.' And '.$date2.': '.$invT->count.'';
}
?>

                </div>
            </div>
        </div>
     </div>
                    
</html>






<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

