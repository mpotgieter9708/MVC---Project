<?php?>
<html>
    <title>New Service</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <script>
         function validateForm() {
            /*var x = document.forms["myForm"]["scode"].value;
            if (x == "") {
                alert("Error: Service code cannot be empty");
                return false;
            }
            else {
                if(x.length > 4)
                alert("Error: Service code cannot contain more than 4 charachters");
                return false;
            }
            
            /*var y = document.forms["myForm"]["sdesc"].value;
            if (y == "") {
                alert("Error: Service description cannot be empty");
                return false;
            }
            
            var z = document.forms["myForm"]["sprice"].value;
            if (z == "") {
                alert("Error: Service description cannot be empty");
                return false;
            }*/
       }
       </script>
     </head>
     
    
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>New Service</h1>
                <hr />
                <div class="panel-body"> 
        <form action='' name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='manager'>
	<input type=hidden name=action value='addService'>
        Service Code:<input type="text" name="scode" value="" class="form-control" required=""/><br>
        Service Description:<input type="text" name="sdesc" value="" class="form-control" required=""/><br>
        Service Price:<input type="text" name="sprice" value="" class="form-control" required=""/><br>
        
        
            <input type="submit" value="Add Service" class="btn-default"/>
        </form>
                </div>
            </div>
        </div>
   </div>
</html>


