<?php?>

<html>
    <title>New Employee</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
        function validateForm() {
			
             var e = document.forms["myForm"]["username"].value;
            if(e == '') {
                alert("Error: Username cannot be blank!");
                return false;
            }
              var b = document.forms["myForm"]["password"].value;
            if(b == '') {
                alert("Error: Password cannot be blank!");
                return false;
            }
            else{
                if (b < 6)
                    {
                alert("Error: Password must contain at least six characters!");
                return false;
                }
            }
            
            var e = document.forms["myForm"]["username"].value;
            if(e == '') {
                alert("Error: Username cannot be blank!");
                return false;
            }
            
            var x = document.forms["myForm"]["surname"].value;
            if(x=='') {
                alert("Error: Surname cannot be blank!");
                return false;
            }
            else{
                if (x.length > 50)
                    {
                alert("Error: Please enter a valid surname!");
                return false;
                }
            }
            
            var y = document.forms["myForm"]["initials"].value;
            if(y == '') {
                alert("Error: Initials cannot be blank!");
                return false;
            }
            else{
                if (y.length > 5)
                    {
                alert("Error: Initials cannot be more than 5 letters!");
                return false;
                }
            }
            
            var x = document.forms["myForm"]["firstname"].value;
            if(x=='') {
                alert("Error: First Name cannot be blank!");
                return false;
            }
            else{
                if (x.length > 50)
                    {
                alert("Error: Please enter a valid first name!");
                return false;
                }
            }
            
            var a = document.forms["myForm"]["idno"].value;
            if(a == '') {
                alert("Error; ID Number cannot be blank!");
                return false;
            }
          
     }
</script>
     </head>
     
    
   <div class="row">
        <div class="col-md-5 col-md-offset-4">
            
            <div class="panel panel-default panel-background">
                <h1>New Employee</h1>
                <hr />
                <div class="panel-body"> 
        <form action='' name='myForm' method="GET" onsubmit="return validateForm()"><input type=hidden name=controller value='manager'>
	<input type=hidden name=action value='addEmployee'>
        User Name:<input type="text" name="username" value="" class="form-control"/><br>
        Password:<input type="text" name="password" value="" class="form-control"/><br>
        Surname:<input type="text" name="surname" value="" class="form-control"/><br>
        Firstname:<input type="text" name="firstname" value="" class="form-control"/><br>
        Initials:<input type="text" name="initials" value="" class="form-control"/><br>
        ID No:<input type="text" name="idno" value="" class="form-control" pattern='(\d{2})(0[123456789]|1[012])(0[123456789]|[12][0123456789]|3[01])(\d{4})([01])(8)(\d{1})' title='13 numeric characters required!'/><br>
        Date Appointed: <input type="date" name="dateappointed" value="<?php echo $dateappointed; ?>" class="form-control"  pattern="(19|20)[1-9]{2}-[0-9]{2}-[0-9]{2}" title='Valid date example: 2018-01-01'/><br>
        Job Description:<select name="jobdesc" class="form-control">
            <option>Washer</option>
            <option>Executive Washer</option>
	</select><br>
        
            <input type="submit" value="Add Employee" class="btn-default"/>
        </form>
                </div>
            </div>
        </div>
   </div>
</html>


