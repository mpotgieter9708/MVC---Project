<DOCTYPE html>
<html>
    
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
  
  <body>
    <header>
        
       <div class="navbar">
            <a href="?controller=manager&action=home"><i class="fa fa-home"></i>Home</a>
            <div class="dropdown">
                <button class="dropbtn"><i class="fa fa-bookmark"></i>Manage Employees
      <i class="fa fa-caret-down"></i>
               
    </button>
    <div class="dropdown-content">
         <a href="?controller=manager&action=addEmployee"><i class="fa fa-plus"></i>Add Employee</a>
            <a href="?controller=manager&action=showAllEmployees"><i class="fa fa-eye"></i>View Employees</a> 
    </div>
  </div> 
             <div class="dropdown">
                <button class="dropbtn"><i class="fa fa-bookmark"></i>Manage Services
      <i class="fa fa-caret-down"></i>
               
    </button>
    <div class="dropdown-content">
          <a href="?controller=manager&action=addService"><i class="fa fa-plus"></i>Add Service</a> 
            <a href="?controller=manager&action=updateService"><i class="fa fa-pencil"></i>Update Services</a>
            <a href="?controller=manager&action=deleteService"><i class="fa fa-eye"></i>View Services</a> 
    </div>
  </div> 
           <a href="?controller=manager&action=assignJob">Assign Jobs<i class="fa fa-pencil"></i></a>
           
           <div class="dropdown">
                <button class="dropbtn"><i class="fa fa-bookmark"></i>Reports
      <i class="fa fa-caret-down"></i>
               
    </button>
    <div class="dropdown-content">
          <a href="?controller=manager&action=invoiceReport"><i class="fa fa-eye"></i>Invoice Report</a> 
          <a href="?controller=manager&action=bookingReport"><i class="fa fa-eye"></i>Bookings Summary Report</a>
          <a href="?controller=manager&action=weeklyBookingReport"><i class="fa fa-eye"></i>Weekly Bookings Report</a>
          <a href="?controller=manager&action=commentReport"><i class="fa fa-eye"></i>Customer Comment Report</a>
          <a href="?controller=manager&action=promotionReport"><i class="fa fa-eye"></i>Customer Promotion Report</a>
          
            
    </div>
  </div> 
             <div class="navbar-right">
                 <a href="index.php">Log off<i class="fa fa-power-off"></i></a>
             <a > Hello Magagane, NV! <i class="fa fa-smile-o"></i></a>
             </div>
        </div>
   <!--<div class="topnav">
  <a class="active" href="employeeHome.php">Home</a>
 <a href="?controller=employee&action=showAllComments"><i class="fa fa-eye"></i>All Comments</a>
   <div class="topnav-right">
   <a href="index.php">Log off</a>
    <a> Hello <?php //echo $initials . ', ' . $surname; ?>!</a>
  </div>
</div>-->
    </header>
      <br>

    <?php 
?>

    <footer>
    
    </footer>
  </body>
</html>





