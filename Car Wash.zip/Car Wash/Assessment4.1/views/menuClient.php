<DOCTYPE html>
<html>
    
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
     </head>
  
  <body>
    <header>
        
        <div class="navbar">
            <a href="?controller=client&action=home"><i class="fa fa-home"></i>Home</a>
             <div class="dropdown">
                <button class="dropbtn"><i class="fa fa-bookmark"></i>Manage Bookings
      <i class="fa fa-caret-down"></i>
               
    </button>
    <div class="dropdown-content">
         <a href="?controller=client&action=addBooking"><i class="fa fa-plus"></i>New Bookings</a>
         <a href="?controller=client&action=showAllBookings"><i class="fa fa-eye"></i>View Bookings</a>
         <a href="?controller=client&action=updateBooking"><i class="fa fa-pencil"></i>Update Bookings</a>
            
    </div>
  </div> 
            <div class="dropdown">
                <button class="dropbtn"><i class="fa fa-car"></i>Manage Vehicles
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="?controller=client&action=showAllVehicles"><i class="fa fa-eye"></i>View Vehicle</a>
      <a href='?controller=client&action=addVehicle'><i class="fa fa-plus"></i>Add Vehicle</a><br>
    </div>
            </div>
                  
            <a href="?controller=client&action=addComment">Make Comment<i class="fa fa-commenting-o"></i></a>
            <div class="navbar navbar-right">
                <a href='?controller=client&action=myProfile'>Profile<i class="fa fa-user"></i></a>
                <a href="index.php">Log off<i class="fa fa-power-off"></i></a>
                <a > Hello <?php echo $surname . ', ' . $initials; ?>! <i class="fa fa-smile-o"></i></a>
            </div>
        </div>
        
    </header>
      <br>

    <?php 
?>

    <footer>
    
    </footer>
  </body>
<html>

