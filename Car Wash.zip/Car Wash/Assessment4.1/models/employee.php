<?php
include ('vehicle.php');
include ('booking.php');
include ('service.php');
include ('comment.php');
include ('invoice.php');
include ('allComments.php');
include ('jobcard.php');
include ('allEmpBookings.php');

 class Employee {
       	public $empno;
	public $initials;
    	public $surname;
	public $username;
        public $idno;
         public $dateappointed;
         public $jobdesc;
         public $firstname;
      
        public function __construct($empno, $surname, $initials,$firstname,$idno,$dateappointed,$jobdesc, $username) {
      		$this->empno = $empno;
      		$this->initials = $initials;
		$this->surname = $surname;
                $this->firstname= $firstname;
                $this->idno= $idno;
                $this->dateappointed= $dateappointed;
                $this->jobdesc= $jobdesc;
	  	$this->username= $username;
            
    	}
        
        public static function allComments($empno) {
      		$list = array();
      		$db = Db::getInstance();   
      		$req = $db->query('SELECT C.Description,CL.Surname,CL.Initials,B.RegNo 
                    FROM booking B,comment C,client CL, vehicle V 
                    WHERE B.JobCardNo = C.CNo
                    AND V.RegNo = B.RegNo
                    AND V.ClCode = CL.ClCode
                    AND B.EmpNo = "'.$empno.'"
                    ORDER BY CL.Surname');
      		
      		foreach($req->fetchAll() as $allComments) {
        		$list[] = new AllComments($allComments['Description'], $allComments['Surname'],$allComments['Initials'],$allComments['RegNo']);
      		}

      	return $list;
    	}
        
        public static function find($username) {
      		$db = Db::getInstance();
		$qry = 'SELECT * FROM employee WHERE Username = "'.$username.'"';
	
      		$db->prepare($qry);
		$req = $db->query($qry);
    		                
      		$employee = $req->fetch();   

      		return new Employee($employee['EmpNo'], $employee['Surname'],$employee['Initials'],$employee['FirstName'],$employee['IdNo'],$employee['DateAppointed'],$employee['JobDesc'], $employee['Username']);
    	}
        
        public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT * FROM employee WHERE empno != 12 ORDER BY Surname');
      //
      		foreach($req->fetchAll() as $employee) {
        		$list[] = new Employee($employee['EmpNo'], $employee['Surname'],$employee['Initials'],$employee['FirstName'],$employee['IdNo'],$employee['DateAppointed'],$employee['JobDesc'], $employee['Username']);
      		}

      	return $list;
    	}
        
        public static function addInvoice($idate,$jobcardno)
                {
		$sql = "INSERT INTO invoice VALUES (NULL, '$idate',(SELECT SPrice FROM service, jobcard WHERE jobcard.SCode = service.SCode AND JobCardNo = $jobcardno),0,NULL)";   
 		$sql1 = "UPDATE booking
                        SET INo = (Select Max(INo) FROM invoice), washed = 1
                        WHERE JobCardNo = $jobcardno";
                $db = Db::getInstance();
               $db->query($sql);
                $db->query($sql1);
	
		
        }
        
        public static function allBooking($empno) {
      		$list = array();
      		$db = Db::getInstance();   
      		$req = $db->query('SELECT booking.JobCardNo, booking.Date, booking.RegNo, booking.Time, service.SDesc,service.SPrice, CASE WHEN carwash.booking.washed = 0 THEN "Not Washed" ELSE "Washed" END as washed 
                    FROM booking, employee,jobcard, service 
                    WHERE booking.JobCardNo = jobcard.JobCardNo
                    AND jobcard.SCode = service.SCode
                    AND booking.EmpNo = "'.$empno.'"
                    AND booking.Date <= now()
                    AND booking.washed = 0
                    GROUP BY booking.JobCardNo');
      		
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'], $booking['RegNo'],$booking['Time'],$booking['SDesc'],$booking['SPrice'],$booking['washed'],$booking['Surname'],$booking['Initials'], $booking['total'],$booking['totalAmnt'],$booking['tot']);
      		}

      	return $list;
        
                
        }
         
        public static function updateStatus($washed,$jobcardno)
        {
		
                                
                $sql = "UPDATE booking
                        SET washed = $washed
                        WHERE JobCardNo = $jobcardno";
                $db = Db::getInstance();
                $db->query($sql);
		
                 
        }
        
         public static function checkVehicle($damage,$damagetype,$jobcardno)
        {
		
                                
                $sql = "UPDATE jobcard
                        SET Damage = $damage, DamageType = '".$damagetype."'
                        WHERE JobCardNo = $jobcardno";
                $db = Db::getInstance();
                $db->query($sql);
		
                 
        }
}
    
 
