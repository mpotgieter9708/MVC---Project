<?php
  class AllComments {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	
	public $description;
        public $surname;
        public $initials;
        public $regno;
   
        public function __construct($description,$surname,$initials,$regno) {
      		
               $this->description  = $description;  
                $this->surname  = $surname; 
                $this->initials  = $initials;
                $this->regno = $regno;
                
                
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT Description,Surname,Initials,B.RegNo 
                    FROM booking B,comment C,client CL, vehicle V, employee E 
                    WHERE B.JobCardNo = C.CNo
                    AND V.RegNo = B.RegNo
                    AND V.ClCode = CL.ClCode
                    AND B.EmpNo = E.EmpNo
                    ORDER BY CL.Surname');
      //
      		foreach($req->fetchAll() as $allComments) {
        		$list[] = new AllComments($allComments['Description'], $allComments['Surname'],$allComments['Initials'],$allComments['RegNo']);
      		}

      	return $list;
    	}


}


