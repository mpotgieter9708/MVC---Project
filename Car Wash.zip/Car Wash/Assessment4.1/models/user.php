<?php

  class User {

    public $username;
    public $role;
   
    	public function __construct($username, $role) {
		
      		$this->username     = $username;
      		$this->role  = $role;
    	}

    	public static function find($username,$password) {

	      	$list = array();
      		$db = Db::getInstance();
	  	$sql = "SELECT U.user_name, R.role_name FROM user U, userrole UR, role R WHERE U.user_name = UR.user_name and R.role_id = UR.role_id AND U.user_name = '$username' AND U.user_password='$password'";
	  	$req = $db->query($sql);
		$i=0;
      		
         	foreach ($req->fetchAll() as $user) {
        		$list[] = new User($user['user_name'], $user['role_name']);
			$i++;
        	}
        	if ($i>0)
			return $list[0];  
	  	else
			return false;
    	}
}  // end of class definition
?>
