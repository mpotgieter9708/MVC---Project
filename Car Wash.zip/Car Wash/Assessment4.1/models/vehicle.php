<?php

  class Vehicle {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $regno;
	public $make;
        public $model;
        public $colour;
        public $year;
   
    	public function __construct($regno, $make,$model,$colour,$year) {
      		$this->regno = $regno;
      		$this->make  = $make;
                $this->model  = $model;
                $this->colour  = $colour;
                $this->year  = $year;
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT * FROM vehicle');
      //
      		foreach($req->fetchAll() as $vehicle) {
        		$list[] = new Vehicle($vehicle['RegNo'], $vehicle['Make'], $vehicle['Model'], $vehicle['Colour'], $vehicle['Year']);
      		}

      	return $list;
    	}


}