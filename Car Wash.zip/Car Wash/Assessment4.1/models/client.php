<?php
include ('vehicle.php');
include ('booking.php');
include ('service.php');
include ('comment.php');

  class Client {
       	public $clcode;
	public $initials;
    	public $surname;
        public $idno;
        public $contactno;
        public $emailaddress;
        public $username;
   
    	public function __construct($clcode, $surname,$initials,$idno,$contactno,$emailaddress, $username) {
      		$this->clcode = $clcode;
      		$this->initials = $initials;
		$this->surname = $surname;
                $this->idno= $idno;
                $this->contactno= $contactno;
                $this->emailaddress= $emailaddress;
                $this->username= $username;
    	}

	public static function allVehicles($clcode) {
      		$list = array();
      		$db = Db::getInstance();   
      		$req = $db->query('SELECT RegNo,Make,Model,Colour,Year FROM vehicle WHERE vehicle.ClCode = "'.$clcode.'"');
      		
      		foreach($req->fetchAll() as $vehicle) {
        		$list[] = new Vehicle($vehicle['RegNo'], $vehicle['Make'], $vehicle['Model'], $vehicle['Colour'], $vehicle['Year']);
      		}

      	return $list;
    	}
        
        public static function find($username) {
      		$db = Db::getInstance();
		$qry = 'SELECT * FROM client WHERE username = "'.$username.'"';
	
      		$db->prepare($qry);
		$req = $db->query($qry);
    		                
      		$client = $req->fetch();   

      		return new Client($client['ClCode'], $client['Surname'], $client['Initials'],$client['IdNo'],$client['ContactNo'],$client['EmailAddress'], $client['Username']);
    	}
        
        public static function addVehicles($regno, $make,$model,$colour,$year,$clcode)
                {
		$sql = "INSERT INTO vehicle (RegNo, Make, Model,Colour,Year,ClCode) VALUES ('$regno', '$make','$model','$colour',$year,'$clcode')";   
 		$db = Db::getInstance();
                $db->query($sql);
		
        }
        
        public static function allBookings($clcode) {
      		$list = array();
      		$db = Db::getInstance();   
      		$req = $db->query('SELECT booking.JobCardNo,Date,Time,booking.RegNo,SDesc,SPrice,booking.washed
                    FROM booking, vehicle,jobcard,service
                    WHERE booking.RegNo = vehicle.RegNo
                    AND jobcard.JobCardNo = booking.JobCardNo
                    AND jobcard.SCode = service.SCode
                    AND booking.Date >= "2018-11-24"
                    AND vehicle.ClCode = "'.$clcode.'"
                    GROUP BY JobCardNo');
    		
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'],$booking['Time'],$booking['RegNo'],$booking['SDesc'],$booking['SPrice'],$booking['washed'],$booking['Surname'],$booking['Initials'], $booking['total'],$booking['totalAmnt'],$booking['tot']);
      		}

      	return $list;
    	}
        
        public static function addBookings($date, $regno,$time,$scode)
                {
		$sql = "INSERT INTO booking VALUES (NULL,'$date','$regno',(SELECT ROUND((RAND() * MAX(EmpNo) - MIN(EmpNo)),0) + 1 from employee WHERE EmpNo != 12),NULL,'$time',0)";   
 		$sql2 = "INSERT INTO jobcard VALUES ('$scode',(SELECT MAX(JobCardNo)FROM Booking),NULL,NULL)";
                $db = Db::getInstance();
                $db->query($sql);
                $db->query($sql2);
        }
         public static function updateBookings($jobcardno,$date,$time,$scode)
                {
		$sql = "UPDATE booking SET booking.Date = '".$date."', booking.Time = '".$time."' WHERE JobCardNo = $jobcardno";   
 		$sql2 = "UPDATE jobcard SET SCode = '".$scode."' WHERE JobCardNo = $jobcardno";
                $db = Db::getInstance();
                $db->query($sql);
                $db->query($sql2);
		
        }
         public static function addComments($description,$regno)
                {
		$sql = "INSERT INTO comment VALUES ((SELECT MAX(JobCardNo)FROM Booking WHERE RegNo = '".$regno."') , '$description')";   
 		$db = Db::getInstance();
                $db->query($sql);
		
        }
        public static function updateClient($clcode, $surname, $initials,$idno,$contactno,$emailaddress) {
      		$db = Db::getInstance();
	  	$sql = "UPDATE client SET Surname = '".$surname."', Initials = '".$initials."',IdNo = '".$idno."' ,ContactNo = '".$contactno."', EmailAddress = '".$emailaddress."' WHERE ClCode = '".$clcode."'";
	  	$db->prepare($sql);
	      	$db->query($sql);
       }
       
         
  }