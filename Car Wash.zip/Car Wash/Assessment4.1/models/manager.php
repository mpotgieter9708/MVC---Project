<?php
//include ('vehicle.php');
//include ('booking.php');
//include ('service.php');
//include ('comment.php');
//include ('invoice.php');
//include ('allComments.php');
//include ('jobcard.php');
include ('employee.php');
//include ('promotion.php');
  class Manager {
       	public $empno;
	public $initials;
    	public $surname;
	public $username;
        public $idno;
         public $dateappointed;
         public $jobdesc;
         public $firstname;
      
        public function __construct($empno, $surname, $initials,$firstname,$idno,$dateappointed,$jobdesc, $username) {
      		$this->empno = $empno;
      		$this->initials = $initials;
		$this->surname = $surname;
                $this->firstname= $firstname;
                $this->idno= $idno;
                $this->dateappointed= $dateappointed;
                $this->jobdesc= $jobdesc;
	  	$this->username= $username;
        }
        
           public static function find($username) {
      		$db = Db::getInstance();
		$qry = 'SELECT * FROM employee WHERE Username = "'.$username.'"';
	
      		$db->prepare($qry);
		$req = $db->query($qry);
    		                
      		$employee = $req->fetch();   

      		return new Manager($manager['EmpNo'], $manager['Surname'],$manager['Initials'],$manager['FirstName'],$manager['IdNo'],$manager['DateAppointed'],$manager['JobDesc'], $manager['Username']);
    	}
        public static function addEmployee($surname, $initials,$firstname,$idno,$dateappointed,$jobdesc, $username,$password)
                {
		$sql = "INSERT INTO employee (EmpNo,Surname,Initials,Firstname,IdNo,DateAppointed,JobDesc,LoginID,Username) VALUES (NULL, '$surname','$initials','$firstname','$idno','$dateappointed','$jobdesc',NULL,'$username')";  
                $sql1 = "INSERT INTO user VALUES ('$username','$password')";
                $sql2 = "INSERT INTO userrole VALUES (2,'$username')";
 		$db = Db::getInstance();
                $db->query($sql);
                $db->query($sql1);
                $db->query($sql2);
		
        }
        
        public static function allEmployee()
                {
                 $list = array();
      		$db = Db::getInstance();   
      		$req = $db->query('SELECT * FROM employee ');
      		
      		foreach($req->fetchAll() as $employee) {
        		$list[] = new Employee($employee['EmpNo'], $employee['Surname'],$employee['Initials'],$employee['FirstName'],$employee['IdNo'],$employee['DateAppointed'],$employee['JobDesc'], $employee['Username']);
      		}

      	return $list;
                 
		}
                
                public static function addService($scode,$sdesc,$sprice)
                {
		$sql = "INSERT INTO service VALUES ('$scode','$sdesc','$sprice')";  
                $db = Db::getInstance();
                $db->query($sql);
		
        }
        
              public static function updateService($scode,$sdesc,$sprice)
                {
		$sql = "UPDATE service SET SDesc = '".$sdesc."', SPrice = '".$sprice."' WHERE SCode = '".$scode."'";  
                $db = Db::getInstance();
                //$db->query($sql);
		$db->prepare($sql);
	      	$db->query($sql);
        }
        
        public static function assignJob($jobcardno,$empno)
                {
		$sql = "UPDATE booking SET EmpNo = '".$empno."' WHERE JobCardNo = $jobcardno";  
                $db = Db::getInstance();
                //$db->query($sql);
		$db->prepare($sql);
	      	$db->query($sql);
        }
        
          public static function customerComment ($empno,$date1,$date2) {
	$db = Db:: getInstance();
	$list = array();
	$sql = "SELECT comment.*,booking.Date,employee.Surname as EmpSur,employee.Initials as EmpInit,booking.RegNo,client.Surname, client.Initials, client.ContactNo, service.SDesc
                        FROM comment,booking, employee, jobcard, service, vehicle, client
                        WHERE booking.EmpNo = employee.EmpNo
                        AND booking.JobCardNo = jobcard.JobCardNo
                        AND jobcard.SCode = service.SCode
                        AND booking.RegNo = vehicle.RegNo
                        AND vehicle.ClCode = client.ClCode
                        AND jobcard.JobCardNo = comment.CNo
                        AND booking.EmpNo LIKE '".$empno."'
                        AND booking.Date BETWEEN '$date1' AND '$date2'
                        ORDER BY carwash.booking.Date, EmpSur";
	
	//echo $sql;
	
	$req = $db->query($sql);
	foreach ($req->fetchAll() as $comment) {
		$list[] = new Comment($comment['CNo'], $comment['Description'],$comment['Date'],$comment['EmpSur'],$comment['EmpInit'],$comment['RegNo'],$comment['Surname'],$comment['Initials'],$comment['ContactNo'],$comment['SDesc']);

	}
	//echo "success with student list";
	return $list;
	}
         public static function deleteService($scode)
                {
		$sql = "DELETE FROM service WHERE SCode = '".$scode."'";  
                $db = Db::getInstance();
                //$db->query($sql);
		try {
		$db->query($sql);
                }
		catch(pdoexception $e) {
		 echo "Error deleting service";
                 
		}
            }
       
  }
