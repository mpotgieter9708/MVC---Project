<?php

  class Invoice {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $ino;
	public $idate;
        public $iamount;
        public $regno;
         public $date;
          public $time;
           public $clsurname;
            public $clinitials;
             public $sdesc;
              public $sprice;
public $count;



        public function __construct($ino, $idate,$iamount,$regno,$date,$time,$clsurname,$clinitials,$sdesc,$sprice,$count) {
      		$this->ino = $ino;
      		$this->idate  = $idate;
                $this->iamount  = $iamount;
                $this->regno =$regno;
         $this->date = $date;
          $this->time=$time;
           $this->clsurname = $clsurname;
           $this->clinitials = $clinitials;
            $this->sdesc =  $sdesc;
             $this->sprice = $sprice;
             $this->count = $count;
             
                
                
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT * FROM invoice');
      //
      		foreach($req->fetchAll() as $invoice) {
        		$list[] = new Invoice($invoice['INo'], $invoice['IDate'],$invoice['IAmount']);
      		}

      	return $list;
    	}
        
        public static function invoiceReport($date1,$date2) {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT invoice.INo, invoice.IDate, booking.RegNo, booking.Date, booking.Time, client.Surname, client.Initials, service.SDesc,service.SPrice
                    FROM invoice, booking, vehicle, jobcard, service, client 
                    WHERE invoice.INo = booking.INo 
                    AND booking.RegNo = vehicle.RegNo 
                    AND booking.JobCardNo = jobcard.JobCardNo 
                    AND jobcard.SCode = service.SCode 
                    AND vehicle.ClCode = client.ClCode 
                    AND (invoice.IDate BETWEEN "'.$date1.'" AND "'.$date2.'")
                    ORDER BY invoice.IDate DESC');
      //
      		foreach($req->fetchAll() as $invoiceR) {
        		$list[] = new Invoice($invoiceR['INo'], $invoiceR['IDate'],$invoice['IAmount'],$invoiceR['RegNo'],$invoiceR['Date'],$invoiceR['Time'],$invoiceR['Surname'],$invoiceR['Initials'],$invoiceR['SDesc'],$invoiceR['SPrice'],$invoiceR['tot']);
      		}

      	return $list;
    	}
        public static function invoiceR($date1,$date2) {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT COUNT(*) as tot
                    FROM invoice
                    WHERE(invoice.IDate BETWEEN "'.$date1.'" AND "'.$date2.'")
                    ORDER BY invoice.IDate DESC');
      //
      		foreach($req->fetchAll() as $invoice) {
        		$list[] = new Invoice($invoice['INo'], $invoice['IDate'],$invoice['IAmount'],$invoice['RegNo'],$invoice['Date'],$invoice['Time'],$invoice['Surname'],$invoice['Initials'],$invoice['SDesc'],$invoice['SPrice'],$invoice['tot']);
      		}

      	return $list;
    	}


}