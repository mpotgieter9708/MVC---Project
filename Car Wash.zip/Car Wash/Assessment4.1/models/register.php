<?php

 class Register {
       	
	public $initials;
    	public $surname;
        public $idno;
        public $contactno;
        public $emailaddress;
        public $username;
        public $password;
        public $regno;
	public $make;
        public $model;
        public $colour;
        public $year;
   
    	public function __construct($surname,$initials,$idno,$contactno,$emailaddress, $username,$password,$regno, $make,$model,$colour,$year) {
      		
      		$this->initials = $initials;
		$this->surname = $surname;
                $this->idno= $idno;
                $this->contactno= $contactno;
                $this->emailaddress= $emailaddress;
                $this->username= $username;
                $this->password=$password;
                $this->regno = $regno;
      		$this->make  = $make;
                $this->model  = $model;
                $this->colour  = $colour;
                $this->year  = $year;
    	}
        
        public static function registerUser($username,$password)
                {
		$sql = "INSERT INTO user(user_password,user_name) 
                        VALUES 
                        ('".$password."','".$username."')";
                $sql1 = "INSERT INTO userrole(role_id,user_name) 
                VALUES (1,'".$username."')";  
 		$db = Db::getInstance();
                $db->query($sql);
                $db->query($sql1);
                
                return $username;
        }
        
        public static function registerClient($surname,$initials,$idno,$contactno,$emailaddress, $username,$regno, $make,$model,$colour,$year)
                {
            
		$sql = "INSERT INTO client (ClCode,Surname,Initials,IdNo,ContactNo,EmailAddress,Username) 
                VALUES 
                (NULL,'".$surname."','".$initials."','".$idno."','".$contactno."','".$emailaddress."','".$username."')";
                $sql1 = "INSERT INTO vehicle(RegNo,Make,Model,Colour,Year,ClCode) 
                VALUES 
                ('".$regno."','".$make."','".$model."','".$colour."','".$year."',(SELECT MAX(ClCode) FROM client))";
 		$db = Db::getInstance();
                $db->query($sql);
                $db->query($sql1);
               
        }
 }

