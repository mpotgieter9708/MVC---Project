<?php
 class AllEmpBooking {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $jobcardno;
	public $date;
        public $regno;
        public $time;
        public $surname;
        public $initials;
         public $empno;
         




        public function __construct($jobcardno, $date,$regno,$time,$surname,$initials,$empno) {
      		$this->jobcardno = $jobcardno;
      		$this->date  = $date;
                $this->regno  = $regno;
                $this->time  = $time;
                $this->surname  = $surname;
                $this->initials  = $initials;
                $this->empno  = $empno;
                
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT B.*,E.Surname,E.Initials FROM booking B,employee E
                        WHERE B.EmpNo = E.EmpNo
                        AND B.Date <= now()
                        AND washed = 0
                        ORDER BY B.JobCardNo');
      //
      		foreach($req->fetchAll() as $allEmpBooking) {
        		$list[] = new AllEmpBooking($allEmpBooking['JobCardNo'], $allEmpBooking['Date'], $allEmpBooking['RegNo'],$allEmpBooking['Time'],$allEmpBooking['Surname'],$allEmpBooking['Initials'],$allEmpBooking['EmpNo']);
      		}

      	return $list;
    	}
 }