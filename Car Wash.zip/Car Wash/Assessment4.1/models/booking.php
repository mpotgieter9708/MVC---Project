<?php

  class Booking {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $jobcardno;
	public $date;
        public $regno;
        public $time;
        public $sdesc;
        public $sprice;
         public $washed;
public $total;
        public $totalAmnt;
        public $surname;
        public $initials;
        public $count;




        public function __construct($jobcardno, $date,$regno,$time,$sdesc,$sprice,$washed,$total, $totalAmnt,$surname, $initials,$count) {
      		$this->jobcardno = $jobcardno;
      		$this->date  = $date;
                $this->regno  = $regno;
                $this->time  = $time;
                $this->sdesc  = $sdesc;
                $this->sprice  = $sprice;
                $this->washed  = $washed;
                $this->total = $total;
      		$this->totalAmnt  = $totalAmnt;
                $this->surname = $surname;
      		$this->initials  = $initials;
                $this->count = $count;
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT B.*,S.SDesc,S.SPrice FROM booking B,jobcard J, service S
                        WHERE B.JobCardNo = J.JobCardNo
                        AND J.SCode = S.SCode');
      //
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'], $booking['RegNo'],$booking['Time'],$booking['SDesc'],$booking['SPrice'],$booking['washed'], $booking['total'],$booking['totalAmnt'],$booking['Surname'],$booking['Initials'],$booking['tot']);
      		}

      	return $list;
    	}
        public static function JobAll() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT booking.*, service.SDesc, service.SPrice 
                        FROM booking, jobcard, service 
                        WHERE booking.JobCardNo = jobcard.JobCardNo
                        AND jobcard.SCode = service.SCode
                        AND booking.Date <= now()
                        AND booking.INo IS NULL 
                        ORDER BY booking.JobCardNo');
      //
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'], $booking['RegNo'],$booking['Time'],$booking['SDesc'],$booking['SPrice'],$booking['washed'], $booking['total'],$booking['totalAmnt'],$booking['Surname'],$booking['Initials'],$booking['tot']);
      		}

      	return $list;
    	}
        public static function bookingReport($date1,$date2) {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT service.SDesc, service.SPrice, COUNT(*) AS total, COUNT(*) * service.SPrice AS totalAmnt 
                        FROM booking, jobcard, service 
                        WHERE booking.JobCardNo = jobcard.JobCardNo 
                        AND jobcard.SCode = service.SCode 
                        AND booking.Date BETWEEN "'.$date1.'" AND "'.$date2.'"
                        GROUP BY  jobcard.SCode ORDER BY  total DESC');
      //
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'], $booking['RegNo'],$booking['Time'],$booking['SDesc'],$booking['SPrice'],$booking['washed'], $booking['total'],$booking['totalAmnt'],$booking['Surname'],$booking['Initials'],$booking['tot']);
      		}

      	return $list;
    	}
        
         public static function weeklyBooking($date1,$date2) {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT booking.*,  service.SDesc, service.SPrice, Surname, Initials
                        FROM booking, jobcard, service, vehicle, client
                        WHERE booking.JobCardNo = jobcard.JobCardNo
                        AND jobcard.SCode = service.SCode
                        AND booking.RegNo = vehicle.RegNo
                        AND vehicle.ClCode = client.ClCode
                        AND booking.Date BETWEEN "'.$date1.'" AND "'.$date2.'"
                        AND booking.INo IS NULL 
                        ORDER BY booking.Date');
      //
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'], $booking['RegNo'],$booking['Time'],$booking['SDesc'],$booking['SPrice'],$booking['washed'], $booking['total'],$booking['totalAmnt'],$booking['Surname'],$booking['Initials'],$booking['tot']);
      		}

      	return $list;
    	}
        
        public static function weeklyB($date1,$date2) {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT COUNT(*) as tot
                        FROM booking
                        WHERE booking.Date BETWEEN "'.$date1.'" AND "'.$date2.'" 
                        AND Ino IS null
                        ORDER BY booking.Date');
      //
      		foreach($req->fetchAll() as $booking) {
        		$list[] = new Booking($booking['JobCardNo'], $booking['Date'], $booking['RegNo'],$booking['Time'],$booking['SDesc'],$booking['SPrice'],$booking['washed'], $booking['total'],$booking['totalAmnt'],$booking['Surname'],$booking['Initials'],$booking['tot']);
      		}

      	return $list;
    	}
        
     
}