<?php
class Promotion {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $emailaddress;
	public $contactno;
        public $regno;
       
public $total;
       
        public $surname;
        public $initials;




        public function __construct($surname, $initials,$regno,$contactno,$emailaddress,$total) {
      		$this->contactno = $contactno;
      		$this->emailaddress  = $emailaddress;
                $this->regno  = $regno;
                
                $this->total = $total;
      		
                $this->surname = $surname;
      		$this->initials  = $initials;
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT Surname,Initials,vehicle.RegNo,ContactNo,EmailAddress,COUNT(*) as Total 
                        FROM client, vehicle, booking 
                        WHERE client.ClCode = vehicle.ClCode 
                        AND vehicle.RegNo = booking.RegNo
                        AND washed = 1 
                        GROUP BY Surname,RegNo
                        HAVING COUNT(*) = 5 ');
      //
      		foreach($req->fetchAll() as $promotion) {
        		$list[] = new Promotion($promotion['Surname'], $promotion['Initials'], $promotion['RegNo'],$promotion['ContactNo'],$promotion['EmailAddress'],$promotion['Total']);
      		}

      	return $list;
    	}
}