<?php

  class Service {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $scode;
	public $sdesc;
        public $sprice;
       
        
   
    	public function __construct($scode, $sdesc,$sprice) {
      		$this->scode = $scode;
      		$this->sdesc  = $sdesc;
                $this->sprice = $sprice;
                
    	}

	public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT * FROM service ORDER BY SCode ');
      //
      		foreach($req->fetchAll() as $service) {
        		$list[] = new Service($service['SCode'], $service['SDesc'], $service['SPrice']);
      		}

      	return $list;
    	}


}

