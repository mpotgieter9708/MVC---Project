<?php

 class Jobcard {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $jobcardno;
	public $scode;
        public $damage;
        public $damagetype;
        




        public function __construct($jobcardno, $scode,$damage,$damagetype) {
      		$this->jobcardno = $jobcardno;
      		$this->scode  = $scode;
                $this->damage  = $damage;
                $this->damagetype  = $damagetype;
               
    	}
        public static function all() {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT J.* FROM jobcard J');
      
      		foreach($req->fetchAll() as $jobcard) {
        		$list[] = new Jobcard($jobcard['JobCardNo'], $jobcard['SCode'], $jobcard['Damage'],$jobcard['DamageType']);
      		}

      	return $list;
    	}
 }

