<?php

  class Comment {
       // they are public so that we can access them using $student->surname (e.g.) directly
    	public $cno;
	public $description;
        public $date;
        public $empSurname;
        public $empInitials;
        public $regno;
        public $clSurname;
        public $clInitials;
        public $contactNo;
        public $sdesc;




        public function __construct($cno, $description,$date,$empSurname,$empInitials,$regno,$clSurname,$clInitials,$contactNo,$sdesc) {
      		$this->cno = $cno;
      		$this->description  = $description;
        $this->date  =        $date;
        $this->empSurname  =$empSurname;
        $this->empInitials  = $empInitials;
        $this->regno  = $regno;
        $this->clSurname  =$clSurname;
        $this->clInitials  =$clInitials;
        $this->contactNo  =$contactNo;
        $this->sdesc  =$sdesc;
                
    	}

	public static function all($date1,$date2) {
      		$list = array();
      		$db = Db::getInstance();
      		$req = $db->query('SELECT comment.*,booking.Date,employee.Surname as EmpSur,employee.Initials as EmpInit,booking.RegNo,client.Surname, client.Initials, client.ContactNo, service.SDesc
                        FROM comment,booking, employee, jobcard, service, vehicle, client
                        WHERE booking.EmpNo = employee.EmpNo
                        AND booking.JobCardNo = jobcard.JobCardNo
                        AND jobcard.SCode = service.SCode
                        AND booking.RegNo = vehicle.RegNo
                        AND vehicle.ClCode = client.ClCode
                        AND jobcard.JobCardNo = comment.CNo
                       AND booking.Date BETWEEN "'.$date1.'" AND "'.$date2.'"
                        ORDER BY carwash.booking.Date, EmpSur');
      //
      		foreach($req->fetchAll() as $comment) {
        		$list[] = new Comment($comment['CNo'], $comment['Description'],$comment['Date'],$comment['EmpSur'],$comment['EmpInit'],$comment['RegNo'],$comment['Surname'],$comment['Initials'],$comment['ContactNo'],$comment['SDesc']);
      		}

      	return $list;
    	}
          


}