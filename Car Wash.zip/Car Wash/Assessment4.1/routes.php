<?php
 function call($controller, $action) {
	  //echo '<br> controller and action '.$controller.' '.$action;
    require_once('controllers/' . $controller . '_controller.php');

    switch($controller) {
        case 'pages':
        $controller = new PagesController();
        break;
        case 'client':
        // we need the model to query the database later in the controller
        	$controller = new ClientController();
		require_once('models/client.php');
     	break;
        case 'employee':
        // we need the model to query the database later in the controller
        	$controller = new EmployeeController();
		require_once('models/employee.php');
     	break;
         case 'manager':
        // we need the model to query the database later in the controller
        	$controller = new ManagerController();
		require_once('models/manager.php');
     	break;
	case 'login':
	     	$controller = new LoginController();
		require_once('models/User.php');
      	break;
        case 'register':
	     	$controller = new RegisterController();
		require_once('models/register.php');
      	break;
	
    }

//session_start();
    $controller->{ $action }();
  }

  // we're adding an entry for the new controller and its actions
  $controllers = array('pages' => array('home', 'error'), 'client' => array('home','showAllVehicles','addVehicle','showAllBookings','addBooking','updateBooking','addComment','myProfile'),'employee' => array('home','showAllComments','addInvoice','updateStatus','checkVehicle'),'manager' => array('home','addEmployee','showAllEmployees','addService','updateService','assignJob','invoiceReport','bookingReport','weeklyBookingReport','commentReport','promotionReport','deleteService'),'login' => array('login'),'register' => array('registerUser','registerClient'));

  if (array_key_exists($controller, $controllers)) {
    if (in_array($action, $controllers[$controller])) {
      call($controller, $action);
    } else {
      call('pages', 'error');
    }
  } else {
    call('pages', 'error');
  }
?>
