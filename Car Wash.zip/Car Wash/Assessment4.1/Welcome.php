<html>
    <title>Welcome!</title>
    <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
      <style>
        a.one:link {color:#ff0000;}
        a.one:visited {color:cyan;}
        a.one:hover {color:hotpink;}
</style>
     <body>
 
   <div class="navbar">
            <a href="Default.php"><i class="fa fa-home"></i>Home</a>
            <div class="navbar-right">
            <a href="index.php">Log in<i class="fa fa-sign-in"></i></a>
            
            </div>
  </div>
         <br>
      <div class="row">
        <div class="col-md-7 col-md-offset-3">
                <div class="panel panel-default panel-background">
                <h1>Congratulations Your Registration Was Successfull!  <i class="fa fa-smile-o"></i></h1>
                <hr />
                <div class="panel-body">
                    <center><h2><strong>** Welcome to Ladies Car Wash **</strong></h2></center>
                    <center><p><strong>** You can now <a class = "one" href="index.php">log in <i class="fa fa-sign-in"></i></a> **</strong></p></center>
                
                    <h3>Things you can do:</h3>
                    <ul>
                        <li>Manage Bookings:</li>
                        <ul>
                            <li><i class="fa fa-plus"></i>New Booking</li>
                            <li><i class="fa fa-eye"></i>View Bookings</li>
                            <li><i class="fa fa-pencil"></i>Update Bookings</li>
                        </ul><br>
                        <li>Manage Vehicles:</li>
                        <ul>
                            <li><i class="fa fa-plus"></i>Add Vehicle</li>
                            <li><i class="fa fa-eye"></i>View Vehicle</li>
                            
                        </ul><br>
                        <li>Make Comment:</li>
                         <ul>
                            <li><i class="fa fa-commenting-o"></i>Tell Us What You Think!</li> 
                        </ul>
                    </ul>
                     
                    
                
                </div>
            </div>
        </div>
    </div>
     </body>
</html>

