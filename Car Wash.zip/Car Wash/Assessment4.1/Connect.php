<?php
session_start();
$con = mysql_connect("localhost","root","root");
if(!$con)
{
    die('Could not connect:'. mysql_error());
}
/*echo 'Connection was successful!';*/
mysql_select_db("carwash", $con);
?>




