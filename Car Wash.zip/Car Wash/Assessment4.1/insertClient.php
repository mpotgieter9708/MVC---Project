<?php

include 'Connect.php';
include 'index.php';

$sql = "INSERT INTO client (ClCode,Surname,Initials,IdNo,ContactNo,EmailAddress,Username) 
    VALUES 
    ('0a8e65a7-b550-4a7d-88e0-50946d145123','$_GET[surname]','$_GET[initials]','$_GET[idno]','$_GET[contactno]','$_GET[email]','Lemon')";
$sql1 = "INSERT INTO vehicle(RegNo,Make,Model,Colour,Year,ClCode) 
    VALUES 
    ('$_GET[regno]','$_GET[make]','$_GET[model]','$_GET[colour]','$_GET[year]','0a8e65a7-b550-4a7d-88e0-50946d145123')";

/*$sq2 = "INSERT INTO booking
 VALUES(NULL,'2018-09-30','ZMS978MP',(SELECT ROUND((RAND() * MAX(EmpNo) - MIN(EmpNo)),0) + 1 from employee),NULL,'09:00',0)";
 
$sql3 = "INSERT INTO jobcard
 VALUES('FULL',(SELECT MAX(JobCardNo)FROM Booking),NULL,NULL)";*/

if(!mysql_query($sql,$con))
{
    //die("Error ". mysql_error());
}
if(!mysql_query($sql1,$con))
{
    //die("Error1 ". mysql_error());
}   
/*if(!mysql_query($sql2,$con))
{
    die("Error2 ". mysql_error());
}  
if(!mysql_query($sql3,$con))
{
    die("Error3 ". mysql_error());
} */  
mysql_close($con);
?>
