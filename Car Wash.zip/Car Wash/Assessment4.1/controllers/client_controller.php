<?php
#include ("models/client.php");
//#include ("models/vehicle.php");
#include ("models/booking.php");
#include ("models/service.php");
#include ("models/comment.php");
  class ClientController {
      
      public function home() {
          
          session_start();
		 $username =$_SESSION['username'];
                 $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
		require_once('views/menuClient.php');	
     		require_once('views/Client/clientHome.php');
	}

      public function showAllVehicles() {
		session_start();
		 $username =$_SESSION['username'];
                $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
		$clcode = Client::find($username)->clcode;
		$vehicle = Client::allVehicles($clcode);             
		require_once('views/menuClient.php');	
     		require_once('views/Client/allVehicles.php');
	}
        
        public function addVehicle() {
            try { 
            
            if(ISSET($_GET['regno'])){
            session_start();
		 $username =$_SESSION['username'];
            $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
            $client = Client::find($username);
            $clcode = $client->clcode;
            $regno = $_GET['regno'];
            $make = $_GET['make'];
            $model = $_GET['model'];
            $colour = $_GET['colour'];
            $year = $_GET['year'];
            Client::addVehicles($regno, $make, $model, $colour, $year, $clcode);
            $vehicle = Client::allVehicles($clcode);
            require_once('views/menuClient.php');		
     	    //require_once('views/Client/addVehicle.php');
            require_once('views/Client/allVehicles.php');
            }
            else{
               session_start();
		 $username =$_SESSION['username'];
            $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
              require_once('views/menuClient.php');		
     	    require_once('views/Client/addVehicle.php');  
            }
            }
            catch(pdoexception $e) {
                    require_once('views/menuClient.php');		
     	   
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                  require_once('views/Client/addVehicle.php');
		}
	}
        
        public function showAllBookings() {
		session_start();
		 $username =$_SESSION['username'];
                $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
		$clcode = Client::find($username)->clcode;
		$booking = Client::allBookings($clcode);
		require_once('views/menuClient.php');		
     		require_once('views/Client/allBookings.php');
               
	}
        
        public function addBooking() {
             try {
		
               
		if (isset($_GET['date']))  {  
                $date = $_GET['date'];
                
            } else {
                $date = date("Y-m-d");
                
            }
            if(ISSET($_GET['scode'])){
           session_start();
		 $username =$_SESSION['username'];
            $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
            $client = Client::find($username);
            $clcode = $client->clcode;
            $regno = $_GET['regno'];
            $date = $_GET['date'];
            $scode = $_GET['scode'];
            $time = $_GET['time'];
            $vehicle = Client::allVehicles($clcode);
            $service = Service::all();
            Client::addBookings($date,$regno, $time, $scode);
            $booking = Client::allBookings($clcode);
            require_once('views/menuClient.php');		
     	    //require_once('views/Client/addBooking.php');
            require_once('views/Client/allBookings.php');
            }
            else{
                session_start();
		 $username =$_SESSION['username'];
                $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
                $client = Client::find($username);
            $clcode = $client->clcode;
                $vehicle = Client::allVehicles($clcode);
            $service = Service::all();
              require_once('views/menuClient.php');		
     	    require_once('views/Client/addBooking.php');  
            
            }
             }
            catch(pdoexception $e) {
                require_once('views/menuClient.php');		
     	    
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like You Tried To Make A Double Booking! Try Again.</p></center>";
                 require_once('views/Client/addBooking.php');  
		}
	}
        
        public function updateBooking() {
             //$username = 'JacobT1';
           try {     
           if(ISSET($_GET['jobcardno'])){
               session_start();
		 $username =$_SESSION['username'];
               $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
            $client = Client::find($username);
            $clcode = $client->clcode;
            $jobcardno = $_GET['jobcardno'];
            $date = $_GET['date'];
            $scode = $_GET['scode'];
            $time = $_GET['time'];
            Client::updateBookings($jobcardno,$date , $time, $scode);
            $booking = Client::allBookings($clcode);
            $bkDate = $booking[0]->date;
            $service = Service::all();
            require_once('views/menuClient.php');
            require_once('views/Client/allBookings.php');
            }
            else{
                session_start();
		 $username =$_SESSION['username'];
                $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
            $client = Client::find($username);
            $clcode = $client->clcode;
            $booking = Client::allBookings($clcode);
            $bkDate = $booking[0]->date;
            
            $service = Service::all();
            require_once('views/menuClient.php');		
     	    require_once('views/Client/updateBooking.php');
            //$booking = Client::allBookings($clcode);
            //require_once('views/Client/allBookings.php');
            }
            }
		catch(pdoexception $e) {
                    $booking = Client::allBookings($clcode);
            $bkDate = $booking[0]->date;
            $service = Service::all();
                    require_once('views/menuClient.php');		
     	   
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                  require_once('views/Client/updateBooking.php');
		}
           }
        
        public function addComment() {
           try {
		   
            if(ISSET($_GET['description'])){
            session_start();
		 $username =$_SESSION['username'];
            $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
            $client = Client::find($username);
            $clcode = $client->clcode;
            $regnolist = Client::allVehicles($clcode);
            $regno = $regnolist[0]->regno;
            $description = $_GET['description'];
            Client::addComments($description,$regno);
            require_once('views/menuClient.php');		
     	    require_once('views/Client/addComment.php');
            }
            else{
                session_start();
		 $username =$_SESSION['username'];
                $surname = Client::find($username)->surname;
                 $initials = Client::find($username)->initials;
                $client = Client::find($username);
            $clcode = $client->clcode;
            $regno = Client::allVehicles($clcode)->regno;
              require_once('views/menuClient.php');		
     	    require_once('views/Client/addComment.php');  
            
            }
            }
		catch(pdoexception $e) {
                    require_once('views/menuClient.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                 require_once('views/Client/addComment.php');  
		}
	}
        
        public function myProfile() {
      try {  
		if (isset($_GET['surname'])) {
                    session_start();
		 $username =$_SESSION['username'];
                    $surname = Client::find($username)->surname;
                    $initials = Client::find($username)->initials;
                        $client=Client::find($username);
			$clcode= $client->clcode;
			$surname = $_GET['surname'];
			$initials = $_GET['initials'];
                        $contactno = $_GET['contactno'];
                        $emailaddress = $_GET['emailaddress'];
                        $idno = $_GET['idno'];
			Client::updateClient($clcode,$surname,$initials,$idno,$contactno,$emailaddress);
		}
                session_start();
		 $username =$_SESSION['username'];
                $surname = Client::find($username)->surname;
                $initials = Client::find($username)->initials;
		$client=Client::find($username);
                /*echo "Surname:".$client->surname;
                echo "Initials:".$client->initials;
                echo "Idno:".$client->idno;
                echo "Contact:".$client->contactno;
                echo "Email:".$client->emailaddress;*/
		require_once('views/menuClient.php');	
      		require_once('views/Client/profile.php');
                
                }
		catch(pdoexception $e) {
                    require_once('views/menuClient.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                require_once('views/Client/profile.php');
		}
	}
	
       
  }