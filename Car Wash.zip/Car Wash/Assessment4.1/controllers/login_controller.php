<?php
include ('models/client.php');
//include ('models/employee.php');
//include ('models/manager.php');
 class LoginController {
	 
    	public function login() {
      	
	        $username = filter_input (INPUT_POST,"username")?filter_input (INPUT_POST,"username"): '';
		$password = filter_input (INPUT_POST,"password")?filter_input (INPUT_POST,"password"): '';
		$user= User::find($username,$password);
		if (!$user) 
                {
                   
                    include ('views/login.php');  
                } 
                else
		{	
                    $user= User::find($username,$password);
			session_start();
			$_SESSION['username'] = $user->username;
                    if ($user->role=='Client') 
                    {
                        $username =/*'JacobT1'*/$_SESSION['username'];
                        $surname = Client::find($username)->surname;
                        $initials = Client::find($username)->initials;
                        require_once('views/menuClient.php'); 
                        require_once ('views/Client/clientHome.php');
                    }
			else
                        {
                           
                            if($user->role=='Employee')
                            {
                                require_once('views/menuEmployee.php');
                                require_once ('views/Employee/employeeHome.php');
                            }
                                else 
                                { 
                                    
                                    require_once('views/menuManager.php');
                                    require_once ('views/Manager/managerHome.php');
                                }
                        }	
		}
    	}
 }

?>
