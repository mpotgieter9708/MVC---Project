<?php
#include ("models/client.php");
include ("models/promotion.php");
//#include ("models/vehicle.php");
//#include ("models/booking.php");
#include ("models/service.php");
#include ("models/comment.php");
//#include ("models/allComments.php");
#include ("models/employee.php");
#include ("models/allEmpBookings.php");
#include ("models/invoiceReport.php");
#include ("models/bookingsReport.php");
//#include ("models/invoiceReport.php");
//#include ("models/invoice.php");
  class ManagerController {
      
       public function home() {
		            
		require_once('views/menuManager.php');	
     		require_once('views/Manager/managerHome.php');
	}
      public function addEmployee() {
		try {
		
                
           if (isset($_GET['dateappointed']))  {  
                $dateappointed = $_GET['dateappointed'];
                
            } else {
                $dateappointed  = date("Y-m-d");
                
            } 
                 if(ISSET($_GET['surname'])){
            $username = $_GET['username'];
            $surname = $_GET['surname'];
            $initials = $_GET['initials'];
            $firstname = $_GET['firstname'];
            $dateappointed = $_GET['dateappointed'];
            $idno = $_GET['idno'];
            $jobdesc = $_GET['jobdesc'];
            $password = $_GET['password'];
            Manager::addEmployee($surname, $initials, $firstname, $idno, $dateappointed, $jobdesc, $username, $password);
            $employee = Manager::allEmployee();
            require_once('views/menuManager.php');		
     	    //require_once('views/Client/addVehicle.php');
            require_once('views/Manager/allEmployees.php');
            }
            else{
                $employee = Manager::allEmployee();
              require_once('views/menuManager.php');		
     	    require_once('views/Manager/addEmployee.php');  
            }
            }
		catch(pdoexception $e) {
                    require_once('views/menuManager.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                 require_once('views/Manager/addEmployee.php');  
                 
		}
		
	}
         public function showAllEmployees() {
             $employee = Manager::allEmployee();
             require_once('views/menuManager.php');		

            require_once('views/Manager/allEmployees.php');
         }
         
         public function addService() {
		try {
		
                
                 if(ISSET($_GET['scode'])){
            $scode = $_GET['scode'];
            $sdesc = $_GET['sdesc'];
            $sprice = $_GET['sprice'];
            Manager::addService($scode, $sdesc, $sprice);
            
            $service = Service::all();
            require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/updateService.php');  
            }
            else{
               $service = Service::all(); 
              require_once('views/menuManager.php');		
     	    require_once('views/Manager/addService.php');  
            }
		}
		catch(pdoexception $e) {
                    require_once('views/menuManager.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                 require_once('views/Manager/addService.php');  
                 
		}
	}
        public function updateService() {
	try {
                 if(ISSET($_GET['sdesc'])){
            $scode = $_GET['scode'];
            $sdesc = $_GET['sdesc'];
            $sprice = $_GET['sprice'];
            Manager::updateService($scode, $sdesc, $sprice);
            
            $service = Service::all();
            require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/viewService.php');
            }
            else{
                $service = Service::all();
              require_once('views/menuManager.php');		
     	    require_once('views/Manager/updateService.php');  
            }
            }
		catch(pdoexception $e) {
                    require_once('views/menuManager.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                  require_once('views/Manager/updateService.php');  
                 
		}
		
           
	}
        public function deleteService() {
		
            if(ISSET($_GET['sdesc'])){
            $scode = $_GET['scode'];
            
            Manager::deleteService($scode);
            
            $service = Service::all();
            require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/viewService.php');
            }
            else{
                $service = Service::all();
              require_once('views/menuManager.php');		
     	    require_once('views/Manager/viewService.php');  
            }
		
           
	}
        
        public function assignJob() {
	try {

            if(ISSET($_GET['empno'])){
            $jobcardno = $_GET['jobcardno'];
            $empno = $_GET['empno'];
            
            Manager::assignJob($jobcardno, $empno);
            
            $allEmpBooking = AllEmpBooking::all();
           
            require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/assignJob.php');
            }
            else{
                $allEmpBooking = AllEmpBooking::all();
                
              require_once('views/menuManager.php');		
     	    require_once('views/Manager/assignJob.php');  
            }
		}
		catch(pdoexception $e) {
                    $allEmpBooking = AllEmpBooking::all();
                    require_once('views/menuManager.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Employee Not Available! Try Again.</p></center>";
                  require_once('views/Manager/assignJob.php');  
                 
		}
	}
        
        public function invoiceReport() {
		//$username ='Valencia';//$_SESSION['username'];
               // $manager = Manager::find($username);
            if (isset($_GET['date1']))  {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];
            } else {
                $prev = date_create('first day of previous month');
 
                $date1 = $prev->format('Y-m-d');
                $future = date_create('last day of previous month');
                $date2 = $future->format('Y-m-d');
            }    
            if (isset($_GET['date1']))  {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];         
            
            $invoiceR = Invoice::invoiceReport($date1,$date2);
            $total = Invoice::invoiceR($date1,$date2);
            require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/invoiceReports.php');
            
            }
            else {
                  $prev = date_create('first day of previous month');
 
                $date1 = $prev->format('Y-m-d');
                $future = date_create('last day of previous month');
                $date2 = $future->format('Y-m-d');
                $invoiceR = Invoice::invoiceReport($date1,$date2);
                $total = Invoice::invoiceR($date1,$date2);
                require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/invoiceReports.php');
            }
            
           
            }
             public function bookingReport() {
		//$username ='Valencia';//$_SESSION['username'];
               // $manager = Manager::find($username);
             if (isset($_GET['date1']))  {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];
            } else {
                 $prev = date_create('first day of previous month');
 
                $date1 = $prev->format('Y-m-d');
                $future = date_create('last day of previous month');
                $date2 = $future->format('Y-m-d');
            }    
            if (isset($_GET['date1']))  {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];
                $booking = Booking::bookingReport($date1,$date2);
                $totalList = Booking::bookingReport($date1,$date2);
                $total = $totalList[0]->totalAmnt + $totalList[1]->totalAmnt + $totalList[2]->totalAmnt + $totalList[3]->totalAmnt;
            require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/bookingReports.php');
            } else {
                  $prev = date_create('first day of previous month');
 
                $date1 = $prev->format('Y-m-d');
                $future = date_create('last day of previous month');
                $date2 = $future->format('Y-m-d');
                $booking = Booking::bookingReport($date1,$date2);
                $totalList = Booking::bookingReport($date1,$date2);
                $total = $totalList[0]->totalAmnt + $totalList[1]->totalAmnt + $totalList[2]->totalAmnt + $totalList[3]->totalAmnt;
                require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/bookingReports.php');
            }
            
            
           
            }
            
            public function weeklyBookingReport() {
             if (isset($_GET['date1'])) {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];
             } 
             else {
                $date1 = date("Y-m-d");
                $seven_days_later = time() + 7*60*60*24;
                $date2 = date('Y-m-d', $seven_days_later);
             }    
            if (isset($_GET['date1'])) {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];    
                $booking = Booking::weeklyBooking($date1,$date2);
                 $total = Booking::weeklyB($date1,$date2);
                require_once('views/menuManager.php');
                require_once('views/Manager/weekBookingReports.php');
            }
            else {
                $date1 = date("Y-m-d");
                $seven_days_later = time() + 7*60*60*24;
                $date2 = date('Y-m-d', $seven_days_later);
                $booking = Booking::weeklyBooking($date1,$date2);
                 $total = Booking::weeklyB($date1,$date2);
                require_once('views/menuManager.php');	
                require_once('views/Manager/weekBookingReports.php');
            
            }
            }
            
            public function commentReport() {
		//$username ='Valencia';//$_SESSION['username'];
               // $manager = Manager::find($username);
             
            if (isset($_GET['date1']))  {  
                $date1 = $_GET['date1'];
                $date2 = $_GET['date2'];
            } else {
                 $prev = date_create('first day of previous month');
 
                $date1 = $prev->format('Y-m-d');
                $future = date_create('last day of previous month');
                $date2 = $future->format('Y-m-d');
            }
            if (isset($_GET['empno'])) {     
                $empno = $_GET['empno'];
                $date1 =$_GET['date1'];
                $date2 =$_GET['date2'];
                $comment = Manager::customerComment($empno,$date1,$date2);
                $employee = Employee::all();
                require_once('views/menuManager.php');		
     	    
                require_once('views/Manager/commentReports.php');
            } else {   
                 $prev = date_create('first day of previous month');
 
                $date1 = $prev->format('Y-m-d');
                $future = date_create('last day of previous month');
                $date2 = $future->format('Y-m-d');
                $comment = Comment::all($date1,$date2);
                $employee = Employee::all();
                 require_once('views/menuManager.php');		
     	    
            require_once('views/Manager/commentReports.php');
                }
            }
		 public function promotionReport() {
             $promotion = Promotion::all();
             require_once('views/menuManager.php');		

            require_once('views/Manager/promotionReports.php');
         }
	}
  

