<?php
#include ("models/client.php");
#include ("models/vehicle.php");
#include ("models/booking.php");
#include ("models/service.php");
#include ("models/comment.php");
#include ("models/allComments.php");
#include ("models/invoice.php");
  class EmployeeController {
       
      public function home() {
         session_start();
		 $username =$_SESSION['username'];
		$surname = Employee::find($username)->surname;
                $initials = Employee::find($username)->initials;            
		require_once('views/menuEmployee.php');	
     		require_once('views/Employee/employeeHome.php');
	}
        
      public function showAllComments() {
		session_start();
		 $username =$_SESSION['username'];
                $surname = Employee::find($username)->surname;
                 $initials = Employee::find($username)->initials; 
                $employee = Employee::find($username);
                /*$surname = $employee->surname;
                $initials = $employee->initials;*/
		$empno = $employee->empno;
                
		$allComments = Employee::allComments($empno);          
		require_once('views/menuEmployee.php');	
     		require_once('views/Employee/allComment.php');
	}
        
        public function addInvoice() {
            try {  
            if(ISSET($_GET['jobcardno'])){
            session_start();
		 $username =$_SESSION['username'];
            $surname = Employee::find($username)->surname;
                 $initials = Employee::find($username)->initials; 
            $employee = Employee::find($username);
            $empno = $employee->empno;
            $idate = $_GET['idate'];
            $jobcardno = $_GET['jobcardno'];
            $allBookings = Booking::JobAll();
            /*$job = "SELECT JobCardNo FROM booking WHERE JobCardNo = 142";
            echo 'Job: '.$job;*/
            Employee::addInvoice($idate, $jobcardno);
            
            require_once('views/menuEmployee.php');		
     	   
            require_once('views/Employee/makeInvoice.php');
            }
            else{
                 session_start();
		 $username =$_SESSION['username'];
            $surname = Employee::find($username)->surname;
                 $initials = Employee::find($username)->initials;
                 $idate = date('Y-m-d');
              require_once('views/menuEmployee.php');		
     	    $allBookings = Booking::JobAll();
            require_once('views/Employee/makeInvoice.php');
            }
             }
		catch(pdoexception $e) {
                    require_once('views/menuEmployee.php');	
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                 require_once('views/Employee/makeInvoice.php');
                }
	}
        
        public function updateStatus() {
           try {
		
                
                
            if(ISSET($_GET['jobcardno'])){
            session_start();
		 $username =$_SESSION['username'];
            $surname = Employee::find($username)->surname;
                 $initials = Employee::find($username)->initials;
            $employee = Employee::find($username);
            $empno = $employee->empno;
            $washed = $_GET['washed'];
            $jobcardno = $_GET['jobcardno'];
            $allBookings = Employee::allBooking($empno);
            //$jobcardno = $allBookings->jobcardno;
            Employee::updateStatus($washed, $jobcardno);
            require_once('views/menuEmployee.php');		
     	   
            require_once('views/Employee/updateStatus.php');
            }
            else{
            session_start();
		 $username =$_SESSION['username'];
            $surname = Employee::find($username)->surname;
            $initials = Employee::find($username)->initials;
            $employee = Employee::find($username);
            $empno = $employee->empno;
            $allBookings = Employee::allBooking($empno);
              require_once('views/menuEmployee.php');		
     	    
            require_once('views/Employee/updateStatus.php');
            }
            }
		catch(pdoexception $e) {
                     require_once('views/menuEmployee.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                 require_once('views/Employee/updateStatus.php');
                 
		}
	}
        
        public function checkVehicle() {
            try {
            if(ISSET($_GET['jobcardno'])){
            session_start();
		 $username =$_SESSION['username'];
            $surname = Employee::find($username)->surname;
            $initials = Employee::find($username)->initials;
            $employee = Employee::find($username);
            $empno = $employee->empno;
            $damage= $_GET['damage'];
            $jobcardno = $_GET['jobcardno'];
             $damagetype= $_GET['damagetype'];
            $allBookings = Employee::allBooking($empno);
            //$jobcardno = $allBookings->jobcardno;
            Employee::checkVehicle($damage, $damagetype, $jobcardno);
            require_once('views/menuEmployee.php');		
     	   
            require_once('views/Employee/checkVehicle.php');
            }
            else{
            session_start();
		 $username =$_SESSION['username'];
            $surname = Employee::find($username)->surname;
            $initials = Employee::find($username)->initials;
            $employee = Employee::find($username);
            $empno = $employee->empno;
            $allBookings = Employee::allBooking($empno);
              require_once('views/menuEmployee.php');		
     	    
            require_once('views/Employee/checkVehicle.php');
            }
            }
            catch(pdoexception $e) {
                require_once('views/menuEmployee.php');
		 echo "<center><p style='color:#CC0000;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
                  require_once('views/Employee/checkVehicle.php');
		}
	}
  }


