<?php
include ('models/register.php');
//include ('models/employee.php');
//include ('models/manager.php');
 class RegisterController {
     
     public function registerUser() {
        try
         {
            if(isset($_POST['username']))
            {
                $username = $_POST['username'];
                $password = $_POST['userpassword'];
                Register::registerUser($username, $password);
                require_once 'views/registerClient.php';
            }
                else
                {
                    require_once 'views/registerUser.php';
                }
         } 
         catch (Exception $e) 
         {
               require_once 'views/registerUser.php';
               echo "<center><p style='color:red;'>Oops, Please Try Different Log In Details.</p></center>";
            
         }
     }
     
     public function registerClient() {
         try
         {
            if(isset($_GET['surname']))
            {
                /*session_start();
		$username = $_SESSION['username'];*/
                $surname = $_GET['surname'];
                $initials = $_GET['initials'];
                $idno = $_GET['idno'];
                $contactno = $_GET['contactno'];
                $emailaddress = $_GET['email'];
                $username = $_GET['username'];
                $password = $_GET['userpassword'];
                Register::registerUser($username, $password);
                //$username = 'Lemon1';
                $regno = $_GET['regno'];
                $make = $_GET['make'];
                $model = $_GET['model'];
                $colour = $_GET['colour'];
                $year = $_GET['year'];
         
                Register::registerClient($surname, $initials, $idno, $contactno, $emailaddress, $username, $regno, $make, $model, $colour, $year);
                 
                require_once 'Welcome.php';
                
               
            }
                else
                    {
                        require_once 'views/registerClient.php';
                    }
         }
        catch(pdoexception $e) 
         {
            require_once 'views/registerClient.php';
            echo "<center><p style='color:red;'>Oops, Looks Like Something Went Wrong! Try Again.</p></center>";
            
	 }
    }
 } 
 
 

