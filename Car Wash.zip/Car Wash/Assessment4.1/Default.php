 
<html>
    <title>Home Page</title>
     <head>
        <link rel="stylesheet" href="StyleSheet.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
     
    <body>
        <div class="navbar">
            <a href="Default.php"><i class="fa fa-home"></i>Home</a>
            <div class="navbar-right">
            <a href="index.php">Log in<i class="fa fa-sign-in"></i></a>
            
            </div>
  </div>

        <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <br>
            <div class="panel panel-default panel-background">
                <h1>Ladies car wash </h1>
                <p>"A lady with a car is a lady with a mind"</p>
                <hr />
                <div class="panel-body">
                    <center><p><strong>**Ladies provide the prefect and clean service**<br>
                        </strong></p></center>
                    <h2>Our Reputation</h2>

                    <p>Over the years we have valeted virtually every type of cars and have built an ever-growing base of satisfied customers. Most of our work is obtained by recommendations from people that demand and deserve the absolute best in car care. Give us a try, we'll be glad to prove our dedication.</p>

                    <p>Any car wash can simply wash your car. We give you the edge in personalized service and attention to detail. We are passionate about keeping your vehicle at showroom condition.</p>
                    <h3>Mini Valet</h3>
                    <ul>
                        <li>Sedans
                        </li>
                        <li>SUVs and Double Cabs
                        </li>
                        <li>Vans and Mini buses
                        </li>
                    </ul>
                    <p>Can be tailored to clients requirements.</p>
                    <h3>Products:</h3>
                    <img alt="" src="autowash-bryanston-02-390x260.jpg" style="width: 237px; height: 139px" /><img alt="" src="autowash-centurion-01-390x260.jpg" style="width: 263px; height: 142px" /><img alt="" src="car-wash-lenasia-tertis-design-autowash-full-valet-02-390x260.jpg" style="width: 227px; height: 146px" />

                    <h3>Find Us On:</h3>
                    <h2><a href="https://www.facebook.com/Ladies-Car-Wash-Services-181795609207439/"><i class="fa fa-facebook-official"></i></a> <a href="https://www.twiter.com"><i class="fa fa-twitter"></i></a> <a href="https://www.instagram.com"><i class="fa fa-instagram"></i></a></h2>
                </div>
            </div>
        </div>
    </div>
    </body>
</html>
 